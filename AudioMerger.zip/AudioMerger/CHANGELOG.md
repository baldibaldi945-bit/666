# Changelog

## 0.2.0 — codecs, archives and app icon

- Added the supplied AxelzeroX23 artwork as the Android launcher icon, with only a slight edge crop and density resizing; preserved the untouched original in references/.
- Added 7-Zip-JBinding archive detection/extraction for 7z, RAR, TAR, GZip, BZip2 and other supported formats; ZIP-based FNMM files are detected by signature.
- Added a native Google astc-codec LDR decoder path to export ASTC textures as PNG.
- Restricted audio conversion to MP3/WAV inputs and OGG Vorbis output, retaining simultaneous multi-track mixing.
- Added offline codec-fetch scripts and Android NDK/CMake GitHub Actions steps.

## 0.1.0 — initial project source

- Created offline WebView application shell and Android host.
- Preserved user-provided UI artwork and audio assets.
- Added V-Slice and Funkin' Maker chart/archive conversion prototypes.
- Added Psych lane-side flip utility.
- Added Sparrow/JSON Spritemap and core Adobe Animate BTA reader.
- Added Funkin' Maker sprite strip atlas builder.
- Added ASTC header inspector and source asset preservation.
- Added limited Haxe/HScript pattern helper and WAV audio mixer.
- Added docs, tests and GitHub Actions Android debug build workflow.


## 0.3.0 — Android 5+ and UI reliability

- Raised the install minimum from API 14 to API 21 (Android 5.0+).
- Added the native WebView file chooser for single/multiple file inputs and safe cancellation handling.
- Removed the duplicate settings artwork path; subpages reuse the original artwork frame.
- Added the developer YouTube link to the social screen and friends list.
- Added partial Saudi Arabic (`ar-SA`) and Brazilian Portuguese (`pt-BR`) UI text.
- Expanded Haxe/HScript-to-Lua patterns, retained callback parameters and isolated unsupported switch/try/catch blocks as TODO comments.
- Added automated Haxe translator and UI wiring tests.
- Applied lossless PNG re-compression while verifying decoded RGBA pixels remain unchanged.


## Repository archive optimization

- Removed the checked-in Android asset mirror because it was byte-for-byte identical to the canonical UI and template source folders.
- Added the Gradle `syncPortYouAssets` task as a `preBuild` dependency; Android assets are recreated automatically before packaging.
- Added generated mirrors to `.gitignore`. No UI, template, code, or media source files were deleted.
