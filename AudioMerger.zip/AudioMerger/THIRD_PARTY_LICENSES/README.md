# Third-party license texts

- `LGPL-2.1.txt` is the GNU Lesser General Public License version 2.1, applicable to the 7-Zip-JBinding-4Android dependency according to its upstream repository. The upstream 7-Zip implementation also notes an unRAR restriction: the RAR decompression source must not be used to recreate a RAR-compatible compressor. This app uses the library for extraction only.
- Google astc-codec uses Apache-2.0; the source and full `LICENSE` file are fetched before native build into `android/app/src/main/cpp/third_party/astc-codec/`.
- OggVorbisEncoder.js documents the wrapper/API as MIT and libogg/libvorbis under Xiph's BSD-like license; `scripts/fetch-codecs.sh` fetches the upstream `LICENSE.txt` alongside the encoder.

Before distributing APKs, retain all applicable license/notice texts and review LGPL requirements for the specific Android packaging method and native ABI. See `THIRD_PARTY_NOTICES.md` and the upstream projects linked there.
