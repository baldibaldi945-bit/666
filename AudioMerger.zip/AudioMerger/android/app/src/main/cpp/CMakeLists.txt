cmake_minimum_required(VERSION 3.10.2)
project(portyou_astc)
set(CMAKE_CXX_STANDARD 11)

set(ASTC_CODEC_DIR "${CMAKE_CURRENT_LIST_DIR}/third_party/astc-codec")
if(NOT EXISTS "${ASTC_CODEC_DIR}/include/astc-codec/astc-codec.h")
  message(FATAL_ERROR "ASTC decoder sources missing. Run sh scripts/fetch-native-deps.sh from the repository root.")
endif()

# Build the upstream decoder source files directly. This avoids requiring Bazel
# or the upstream unit-test project's optional GoogleTest download on Android.
file(GLOB ASTC_BASE_SOURCES "${ASTC_CODEC_DIR}/src/base/*.cc")
file(GLOB ASTC_DECODER_SOURCES "${ASTC_CODEC_DIR}/src/decoder/*.cc")
set(ASTC_SOURCES ${ASTC_BASE_SOURCES} ${ASTC_DECODER_SOURCES})
if(NOT ASTC_SOURCES)
  message(FATAL_ERROR "No ASTC decoder C++ sources found in the fetched source archive.")
endif()

add_library(astc_codec STATIC ${ASTC_SOURCES})
set_target_properties(astc_codec PROPERTIES POSITION_INDEPENDENT_CODE ON)
target_include_directories(astc_codec PUBLIC
  "${ASTC_CODEC_DIR}/include"
  "${ASTC_CODEC_DIR}/src"
  "${ASTC_CODEC_DIR}/src/base"
  "${ASTC_CODEC_DIR}/src/decoder")

add_library(portyou_astc SHARED astc_jni.cpp)
target_include_directories(portyou_astc PRIVATE "${ASTC_CODEC_DIR}/include")
target_link_libraries(portyou_astc astc_codec log)
