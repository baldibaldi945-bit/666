#include <jni.h>
#include <stdint.h>
#include <limits>
#include <vector>
#include <astc-codec/astc-codec.h>

namespace {
const size_t kHeaderSize = 16;
const size_t kMaxPixels = 2u * 1024u * 1024u;
uint32_t read24(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) |
           (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16);
}
bool footprint(uint8_t x, uint8_t y, astc_codec::FootprintType* out) {
    using astc_codec::FootprintType;
    if (x == 4 && y == 4) *out = FootprintType::k4x4;
    else if (x == 5 && y == 4) *out = FootprintType::k5x4;
    else if (x == 5 && y == 5) *out = FootprintType::k5x5;
    else if (x == 6 && y == 5) *out = FootprintType::k6x5;
    else if (x == 6 && y == 6) *out = FootprintType::k6x6;
    else if (x == 8 && y == 5) *out = FootprintType::k8x5;
    else if (x == 8 && y == 6) *out = FootprintType::k8x6;
    else if (x == 8 && y == 8) *out = FootprintType::k8x8;
    else if (x == 10 && y == 5) *out = FootprintType::k10x5;
    else if (x == 10 && y == 6) *out = FootprintType::k10x6;
    else if (x == 10 && y == 8) *out = FootprintType::k10x8;
    else if (x == 10 && y == 10) *out = FootprintType::k10x10;
    else if (x == 12 && y == 10) *out = FootprintType::k12x10;
    else if (x == 12 && y == 12) *out = FootprintType::k12x12;
    else return false;
    return true;
}
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_axelzerox23_portyou_AstcCodec_decodeAstc(JNIEnv* env, jclass, jbyteArray input) {
    if (input == NULL) return NULL;
    const jsize length = env->GetArrayLength(input);
    if (length < static_cast<jsize>(kHeaderSize)) return NULL;
    std::vector<uint8_t> bytes(static_cast<size_t>(length));
    env->GetByteArrayRegion(input, 0, length, reinterpret_cast<jbyte*>(&bytes[0]));
    if (env->ExceptionCheck()) return NULL;

    // ASTC file identifier: 13 AB A1 5C. The full file, including the 16-byte header,
    // is passed to the reference decoder.
    if (bytes[0] != 0x13 || bytes[1] != 0xAB || bytes[2] != 0xA1 || bytes[3] != 0x5C) return NULL;
    const uint8_t blockX = bytes[4], blockY = bytes[5], blockZ = bytes[6];
    const uint32_t width = read24(&bytes[7]);
    const uint32_t height = read24(&bytes[10]);
    const uint32_t depth = read24(&bytes[13]);
    if (blockZ != 1 || depth != 1 || width == 0 || height == 0) return NULL;
    const uint64_t pixels = static_cast<uint64_t>(width) * height;
    if (pixels > kMaxPixels || pixels > (std::numeric_limits<size_t>::max() / 4)) return NULL;

    astc_codec::FootprintType fp;
    if (!footprint(blockX, blockY, &fp)) return NULL;
    std::vector<uint8_t> rgba(static_cast<size_t>(pixels) * 4);
    const bool ok = astc_codec::ASTCDecompressToRGBA(
        &bytes[0], bytes.size(), width, height, fp,
        &rgba[0], rgba.size(), static_cast<size_t>(width) * 4);
    if (!ok || rgba.size() > static_cast<size_t>(std::numeric_limits<jsize>::max())) return NULL;
    jbyteArray result = env->NewByteArray(static_cast<jsize>(rgba.size()));
    if (result == NULL) return NULL;
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(rgba.size()), reinterpret_cast<const jbyte*>(&rgba[0]));
    return result;
}
