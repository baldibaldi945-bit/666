package com.axelzerox23.portyou;

import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.content.res.AssetManager;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.util.Base64;
import android.Manifest;
import android.content.pm.PackageManager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.nio.charset.Charset;
import java.lang.reflect.Method;

import net.sf.sevenzipjbinding.ExtractAskMode;
import net.sf.sevenzipjbinding.ExtractOperationResult;
import net.sf.sevenzipjbinding.IArchiveExtractCallback;
import net.sf.sevenzipjbinding.IArchiveOpenCallback;
import net.sf.sevenzipjbinding.IInArchive;
import net.sf.sevenzipjbinding.ISequentialOutStream;
import net.sf.sevenzipjbinding.PropID;
import net.sf.sevenzipjbinding.SevenZip;
import net.sf.sevenzipjbinding.SevenZipException;
import net.sf.sevenzipjbinding.impl.RandomAccessFileInStream;

/**
 * Small local WebView host for PortYou Studio.
 * Min SDK 21 (Android 5.0); WebView file chooser and archive extraction are supported.
 * The JavaScript bridge is only exposed to the bundled local assets.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_ARCHIVE = 7301;
    private static final int REQUEST_STORAGE = 7302;
    private static final int REQUEST_ASTC = 7303;
    private static final int REQUEST_WEB_FILE = 7304;
    private static final long MAX_ARCHIVE_BYTES = 2L * 1024L * 1024L * 1024L;
    private static final long MAX_EXTRACTED_BYTES = 2L * 1024L * 1024L * 1024L;
    private static final int BUFFER_SIZE = 65536;
    private WebView webView;
    private ValueCallback<Uri[]> pendingWebFileCallback;
    private File appRoot;
    private File inputRoot;
    private File outputRoot;
    private File archiveFile;
    private String archiveName = "";
    private String lastMessage = "";
    private String lastAstcOutput = "";
    private String lastAstcError = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appRoot = new File(getFilesDir(), "portyou");
        inputRoot = new File(appRoot, "input");
        outputRoot = new File(appRoot, "output");
        ensureDir(appRoot); ensureDir(inputRoot); ensureDir(outputRoot);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalUrl(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalUrl(request == null ? null : request.getUrl().toString());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (pendingWebFileCallback != null) {
                    pendingWebFileCallback.onReceiveValue(null);
                    pendingWebFileCallback = null;
                }
                pendingWebFileCallback = filePathCallback;
                try {
                    Intent picker = fileChooserParams.createIntent();
                    if (fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(picker, REQUEST_WEB_FILE);
                    return true;
                } catch (Exception firstError) {
                    try {
                        Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        if (fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                            fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                        }
                        startActivityForResult(Intent.createChooser(fallback, "اختيار الملفات"), REQUEST_WEB_FILE);
                        return true;
                    } catch (Exception secondError) {
                        if (pendingWebFileCallback != null) pendingWebFileCallback.onReceiveValue(null);
                        pendingWebFileCallback = null;
                        showToast("تعذر فتح مدير الملفات: " + secondError.getMessage());
                        return true;
                    }
                }
            }
        });
        webView.addJavascriptInterface(new PortYouBridge(), "Android");
        if (Build.VERSION.SDK_INT >= 19) WebView.setWebContentsDebuggingEnabled(false);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");

        // Android 5 grants legacy storage permissions at install time; Android 6+ requires
        // a runtime request. Reflection keeps this method safe on API 21/22.
        if (Build.VERSION.SDK_INT >= 23) requestStoragePermissionCompat();
    }

    private void requestStoragePermissionCompat() {
        try {
            Method check = Activity.class.getMethod("checkSelfPermission", String.class);
            Integer granted = (Integer) check.invoke(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            if (granted != PackageManager.PERMISSION_GRANTED) {
                Method request = Activity.class.getMethod("requestPermissions", String[].class, int.class);
                request.invoke(this, new Object[]{new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_STORAGE});
            }
        } catch (Exception ignored) { }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.loadUrl("javascript:if(window.onHostPause)window.onHostPause();");
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.loadUrl("javascript:if(window.onHostResume)window.onHostResume();");
    }

    @Override
    protected void onDestroy() {
        if (pendingWebFileCallback != null) {
            pendingWebFileCallback.onReceiveValue(null);
            pendingWebFileCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private boolean openExternalUrl(String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return false;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception error) {
            showToast("تعذر فتح الرابط: " + error.getMessage());
        }
        return true;
    }

    private void ensureDir(File f) { if (!f.exists()) f.mkdirs(); }

    private void notifyWeb(final String function) {
        runOnUiThread(new Runnable() { @Override public void run() {
            if (webView != null) webView.loadUrl("javascript:" + function + "();");
        }});
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() { @Override public void run() {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
        }});
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_WEB_FILE) {
            Uri[] selected = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    selected = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) selected[i] = clip.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    selected = new Uri[]{data.getData()};
                }
            }
            if (pendingWebFileCallback != null) pendingWebFileCallback.onReceiveValue(selected);
            pendingWebFileCallback = null;
            return;
        }
        if (resultCode != RESULT_OK || data == null) return;
        final Uri uri = data.getData();
        if (uri == null) return;
        if (requestCode == REQUEST_ASTC) {
            new Thread(new Runnable() { @Override public void run() {
                try { decodeAstcFromUri(uri); }
                catch (Throwable ex) { lastAstcError = ex.getMessage() == null ? ex.toString() : ex.getMessage(); lastAstcOutput = ""; }
                notifyWeb("onAstcDecoded");
            }}).start();
            return;
        }
        if (requestCode != REQUEST_ARCHIVE) return;
        new Thread(new Runnable() { @Override public void run() {
            try {
                importAndExtract(uri);
                lastMessage = "Archive loaded: " + archiveName;
                notifyWeb("onNativeArchiveLoaded");
                showToast("تم فتح الأرشيف أوفلاين: " + archiveName);
            } catch (Exception ex) {
                lastMessage = "Import failed: " + ex.getMessage();
                notifyWeb("onNativeArchiveFailed");
                showToast(lastMessage);
            }
        }}).start();
    }

    private String displayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) return cursor.getString(column);
            }
        } catch (Exception ignored) { }
        finally { if (cursor != null) cursor.close(); }
        String fallback = uri.getLastPathSegment();
        return fallback == null ? "mod.archive" : fallback;
    }

    private void importAndExtract(Uri uri) throws IOException {
        if (inputRoot.exists()) deleteRecursive(inputRoot);
        ensureDir(inputRoot);
        archiveName = displayName(uri);
        archiveFile = new File(appRoot, "import-source.archive");
        InputStream source = getContentResolver().openInputStream(uri);
        if (source == null) throw new IOException("Cannot open selected archive");
        OutputStream copy = new BufferedOutputStream(new FileOutputStream(archiveFile));
        byte[] buffer = new byte[BUFFER_SIZE];
        long copied = 0; int read;
        try {
            while ((read = source.read(buffer)) != -1) {
                copied += read;
                if (copied > MAX_ARCHIVE_BYTES) throw new IOException("Archive exceeds the 2GB limit");
                copy.write(buffer, 0, read);
            }
        } finally { try { source.close(); } catch (Exception ignored) {} try { copy.close(); } catch (Exception ignored) {} }
        if (isZipContainer(archiveFile)) {
            unzipSafely(archiveFile, inputRoot);
        } else {
            extractSevenZipSafely(archiveFile, inputRoot);
        }
    }

    private boolean isZipContainer(File file) throws IOException {
        InputStream in = new BufferedInputStream(new FileInputStream(file));
        byte[] sig = new byte[4]; int count;
        try { count = in.read(sig); } finally { in.close(); }
        return count >= 4 && sig[0] == 'P' && sig[1] == 'K' &&
            ((sig[2] == 3 && sig[3] == 4) || (sig[2] == 5 && sig[3] == 6) || (sig[2] == 7 && sig[3] == 8));
    }

    private void extractSevenZipSafely(File archiveFile, File destination) throws IOException {
        RandomAccessFile raf = null;
        RandomAccessFileInStream stream = null;
        IInArchive archive = null;
        final long[] expanded = new long[]{0};
        final OutputStream[] activeOutput = new OutputStream[]{null};
        try {
            raf = new RandomAccessFile(archiveFile, "r");
            stream = new RandomAccessFileInStream(raf);
            archive = SevenZip.openInArchive(null, stream, new IArchiveOpenCallback() {
                @Override public void setTotal(Long files, Long bytes) { }
                @Override public void setCompleted(Long files, Long bytes) { }
            });
            final IInArchive openedArchive = archive;
            archive.extract(null, false, new IArchiveExtractCallback() {
                @Override public ISequentialOutStream getStream(int index, ExtractAskMode mode) throws SevenZipException {
                    try {
                        if (activeOutput[0] != null) { activeOutput[0].close(); activeOutput[0] = null; }
                        if (mode == ExtractAskMode.SKIP) return null;
                        String entryName = openedArchive.getStringProperty(index, PropID.PATH);
                        if (entryName == null || entryName.length() == 0) return null;
                        Object folderValue = openedArchive.getProperty(index, PropID.IS_FOLDER);
                        boolean folder = Boolean.TRUE.equals(folderValue);
                        File target = safeChild(destination, entryName.replace('\\', '/'));
                        if (folder) { ensureDir(target); return null; }
                        File parent = target.getParentFile(); if (parent != null) ensureDir(parent);
                        final OutputStream out = new BufferedOutputStream(new FileOutputStream(target));
                        activeOutput[0] = out;
                        return new ISequentialOutStream() {
                            @Override public int write(byte[] data) throws SevenZipException {
                                if (data == null) return 0;
                                expanded[0] += data.length;
                                if (expanded[0] > MAX_EXTRACTED_BYTES) throw new SevenZipException("Expanded archive exceeds 2GB");
                                try { out.write(data); return data.length; }
                                catch (IOException io) { throw new SevenZipException(io.getMessage()); }
                            }
                        };
                    } catch (IOException io) { throw new SevenZipException(io.getMessage()); }
                }
                @Override public void prepareOperation(ExtractAskMode mode) { }
                @Override public void setOperationResult(ExtractOperationResult result) throws SevenZipException {
                    if (activeOutput[0] != null) {
                        try { activeOutput[0].close(); } catch (IOException io) { throw new SevenZipException(io.getMessage()); }
                        activeOutput[0] = null;
                    }
                    if (result != ExtractOperationResult.OK) throw new SevenZipException("Archive extraction failed: " + result);
                }
                @Override public void setTotal(long total) { }
                @Override public void setCompleted(long complete) { }
            });
        } catch (SevenZipException ex) {
            throw new IOException("Unsupported, damaged, or encrypted archive: " + ex.getMessage(), ex);
        } finally {
            if (activeOutput[0] != null) try { activeOutput[0].close(); } catch (Exception ignored) { }
            if (archive != null) try { archive.close(); } catch (Exception ignored) { }
            if (stream != null) try { stream.close(); } catch (Exception ignored) { }
            if (raf != null) try { raf.close(); } catch (Exception ignored) { }
        }
    }

    private String safeFileName(String name) {
        String clean = name == null ? "astc-image" : name.replace('\\', '/');
        int slash = clean.lastIndexOf('/'); if (slash >= 0) clean = clean.substring(slash + 1);
        clean = clean.replaceAll("[^A-Za-z0-9._-]", "_");
        return clean.length() == 0 ? "astc-image" : clean;
    }

    private void decodeAstcFromUri(Uri uri) throws IOException {
        lastAstcError = ""; lastAstcOutput = "";
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("Cannot open ASTC file");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        byte[] chunk = new byte[BUFFER_SIZE]; int n;
        try {
            while ((n = in.read(chunk)) != -1) {
                if (bytes.size() + n > 64 * 1024 * 1024) throw new IOException("ASTC file is larger than 64MB");
                bytes.write(chunk, 0, n);
            }
        } finally { in.close(); }
        byte[] astc = bytes.toByteArray();
        if (astc.length < 16 || (astc[0] & 255) != 0x13 || (astc[1] & 255) != 0xAB || (astc[2] & 255) != 0xA1 || (astc[3] & 255) != 0x5C) throw new IOException("The selected file is not a standard ASTC file");
        byte[] rgba;
        try { rgba = AstcCodec.decodeAstc(astc); }
        catch (Throwable error) { throw new IOException("ASTC native decoder could not be loaded: " + error.getMessage()); }
        if (rgba == null) throw new IOException("Unsupported ASTC footprint, dimensions, or HDR profile");
        int width = (astc[7] & 255) | ((astc[8] & 255) << 8) | ((astc[9] & 255) << 16);
        int height = (astc[10] & 255) | ((astc[11] & 255) << 8) | ((astc[12] & 255) << 16);
        long pixelCount = (long) width * height;
        if (width <= 0 || height <= 0 || pixelCount > 2L * 1024L * 1024L || rgba.length != pixelCount * 4) throw new IOException("ASTC dimensions exceed the safe image limit");
        int[] pixels = new int[(int) pixelCount];
        for (int i = 0, p = 0; i < rgba.length; i += 4, p++) {
            int r = rgba[i] & 255, g = rgba[i + 1] & 255, b = rgba[i + 2] & 255, a = rgba[i + 3] & 255;
            pixels[p] = (a << 24) | (r << 16) | (g << 8) | b;
        }
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
        File astcDir = new File(outputRoot, "astc-decoded"); ensureDir(astcDir);
        String outputName = safeFileName(displayName(uri));
        if (outputName.toLowerCase().endsWith(".astc")) outputName = outputName.substring(0, outputName.length() - 5);
        File png = new File(astcDir, outputName + ".png");
        OutputStream out = new BufferedOutputStream(new FileOutputStream(png));
        try { if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new IOException("PNG encoding failed"); }
        finally { out.close(); bitmap.recycle(); }
        lastAstcOutput = "astc-decoded/" + png.getName();
    }

    private void unzipSafely(File zip, File destination) throws IOException {
        ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)));
        byte[] buffer = new byte[BUFFER_SIZE];
        long expanded = 0;
        try {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                String name = entry.getName().replace('\\', '/');
                if (name.startsWith("/") || name.indexOf("../") >= 0 || name.equals("..") || name.startsWith("../")) {
                    zis.closeEntry(); continue;
                }
                File target = safeChild(destination, name);
                if (entry.isDirectory()) { ensureDir(target); zis.closeEntry(); continue; }
                File parent = target.getParentFile(); if (parent != null) ensureDir(parent);
                OutputStream out = new BufferedOutputStream(new FileOutputStream(target));
                int n;
                try {
                    while ((n = zis.read(buffer)) != -1) {
                        expanded += n;
                        if (expanded > MAX_EXTRACTED_BYTES) throw new IOException("Expanded archive exceeds 2GB");
                        out.write(buffer, 0, n);
                    }
                } finally { out.close(); }
                zis.closeEntry();
            }
        } finally { zis.close(); }
    }

    private File safeChild(File root, String relative) throws IOException {
        File base = root.getCanonicalFile();
        File child = new File(root, relative).getCanonicalFile();
        String prefix = base.getPath() + File.separator;
        if (!child.getPath().startsWith(prefix) && !child.equals(base)) throw new IOException("Unsafe path inside archive");
        return child;
    }

    private void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) { File[] list = f.listFiles(); if (list != null) for (int i=0;i<list.length;i++) deleteRecursive(list[i]); }
        f.delete();
    }

    public class PortYouBridge {
        @JavascriptInterface public void pickAstcFile() {
            runOnUiThread(new Runnable() { @Override public void run() {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*"); intent.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(Intent.createChooser(intent, "اختيار ملف ASTC"), REQUEST_ASTC); }
                catch (Exception e) { lastAstcError = e.getMessage(); notifyWeb("onAstcDecoded"); }
            }});
        }

        @JavascriptInterface public String getLastAstcOutput() { return lastAstcOutput; }
        @JavascriptInterface public String getLastAstcError() { return lastAstcError; }
        @JavascriptInterface public String readOutputBase64File(String relative) {
            try { File f = safeChild(outputRoot, relative); if (!f.isFile() || f.length() > 20L * 1024L * 1024L) return "";
                return Base64.encodeToString(readAll(f, 20 * 1024 * 1024), Base64.NO_WRAP);
            } catch (Exception ex) { lastMessage = ex.getMessage(); return ""; }
        }

        @JavascriptInterface public void pickArchive() {
            runOnUiThread(new Runnable() { @Override public void run() {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(Intent.createChooser(intent, "اختيار أرشيف المود"), REQUEST_ARCHIVE); }
                catch (Exception e) { showToast("تعذر فتح مدير الملفات: " + e.getMessage()); }
            }});
        }

        @JavascriptInterface public void clearOutput() {
            try { deleteRecursive(outputRoot); ensureDir(outputRoot); }
            catch (Exception ex) { lastMessage = ex.getMessage(); }
        }

        @JavascriptInterface public boolean seedModTemplate(String relative) {
            try {
                File target = safeChild(outputRoot, relative);
                if (target.exists()) deleteRecursive(target);
                ensureDir(target);
                copyAssetFolder("psych-template", target);
                return true;
            } catch (Exception ex) { lastMessage = ex.getMessage(); return false; }
        }

        @JavascriptInterface public String getArchiveName() { return archiveName; }
        @JavascriptInterface public String getLastMessage() { return lastMessage; }

        @JavascriptInterface public String listArchiveFiles() {
            StringBuilder json = new StringBuilder("[");
            List<File> list = new ArrayList<File>();
            walk(inputRoot, list);
            Collections.sort(list, new Comparator<File>() { @Override public int compare(File a, File b) { return a.getPath().compareToIgnoreCase(b.getPath()); }});
            boolean first = true;
            for (int i = 0; i < list.size(); i++) {
                File f = list.get(i);
                if (!f.isFile()) continue;
                String path = relativeTo(inputRoot, f);
                if (!first) json.append(','); first = false;
                json.append("{\"path\":\"").append(jsonEscape(path)).append("\",\"name\":\"")
                    .append(jsonEscape(f.getName())).append("\",\"size\":").append(f.length()).append('}');
            }
            return json.append(']').toString();
        }

        @JavascriptInterface public String readTextFile(String relative) {
            try {
                File f = safeChild(inputRoot, relative);
                if (!f.exists() || !f.isFile()) return "";
                if (f.length() > 8L * 1024L * 1024L) return "";
                byte[] data = readAll(f, 8 * 1024 * 1024);
                return new String(data, Charset.forName("UTF-8"));
            } catch (Exception ex) { lastMessage = ex.getMessage(); return ""; }
        }

        @JavascriptInterface public String readBase64File(String relative) {
            try {
                File f = safeChild(inputRoot, relative);
                if (!f.exists() || !f.isFile() || f.length() > 15L * 1024L * 1024L) return "";
                return Base64.encodeToString(readAll(f, 15 * 1024 * 1024), Base64.NO_WRAP);
            } catch (Exception ex) { lastMessage = ex.getMessage(); return ""; }
        }

        @JavascriptInterface public boolean writeTextFile(String relative, String content) {
            try {
                File f = safeChild(outputRoot, relative);
                File parent = f.getParentFile(); if (parent != null) ensureDir(parent);
                OutputStream out = new BufferedOutputStream(new FileOutputStream(f));
                out.write(content.getBytes("UTF-8")); out.close(); return true;
            } catch (Exception ex) { lastMessage = ex.getMessage(); return false; }
        }

        @JavascriptInterface public boolean writeBase64File(String relative, String base64) {
            try {
                File f = safeChild(outputRoot, relative);
                File parent = f.getParentFile(); if (parent != null) ensureDir(parent);
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                if (data.length > 64 * 1024 * 1024) throw new IOException("Generated image exceeds 64MB");
                OutputStream out = new BufferedOutputStream(new FileOutputStream(f)); out.write(data); out.close(); return true;
            } catch (Exception ex) { lastMessage = ex.getMessage(); return false; }
        }

        @JavascriptInterface public boolean copyInputFile(String inputRelative, String outputRelative) {
            try {
                File src = safeChild(inputRoot, inputRelative);
                File dst = safeChild(outputRoot, outputRelative);
                if (!src.exists() || !src.isFile()) return false;
                File parent = dst.getParentFile(); if (parent != null) ensureDir(parent);
                InputStream in = new BufferedInputStream(new FileInputStream(src));
                OutputStream out = new BufferedOutputStream(new FileOutputStream(dst));
                byte[] b = new byte[BUFFER_SIZE]; int n;
                try { while ((n = in.read(b)) != -1) out.write(b, 0, n); }
                finally { in.close(); out.close(); }
                return true;
            } catch (Exception ex) { lastMessage = ex.getMessage(); return false; }
        }

        @JavascriptInterface public String createOutputZip() {
            try {
                File downloads = new File(Environment.getExternalStorageDirectory(), "Download");
                if (!downloads.exists()) downloads = new File(Environment.getExternalStorageDirectory(), "Downloads");
                if (!downloads.exists()) ensureDir(downloads);
                File target = new File(downloads, "PortYou-output.zip");
                zipDirectory(outputRoot, target);
                return "تم حفظ الملف: " + target.getAbsolutePath();
            } catch (Exception ex) { lastMessage = ex.getMessage(); return "فشل إنشاء ZIP: " + ex.getMessage(); }
        }
    }

    private void copyAssetFolder(String assetPath, File destination) throws IOException {
        AssetManager assets = getAssets();
        String[] children = assets.list(assetPath);
        if (children != null && children.length > 0) {
            ensureDir(destination);
            for (int i = 0; i < children.length; i++) {
                copyAssetFolder(assetPath + "/" + children[i], new File(destination, children[i]));
            }
            return;
        }
        File parent = destination.getParentFile();
        if (parent != null) ensureDir(parent);
        InputStream in = new BufferedInputStream(assets.open(assetPath));
        OutputStream out = new BufferedOutputStream(new FileOutputStream(destination));
        byte[] buffer = new byte[8192]; int count;
        try { while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count); }
        finally { try { in.close(); } finally { out.close(); } }
    }

    private void walk(File root, List<File> output) {
        File[] list = root.listFiles(); if (list == null) return;
        for (int i = 0; i < list.length; i++) { if (list[i].isDirectory()) walk(list[i], output); else output.add(list[i]); }
    }

    private String relativeTo(File root, File child) {
        String a = root.getAbsolutePath(), b = child.getAbsolutePath();
        if (b.startsWith(a)) return b.substring(a.length() + 1).replace(File.separatorChar, '/');
        return child.getName();
    }

    private byte[] readAll(File f, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        InputStream in = new BufferedInputStream(new FileInputStream(f));
        byte[] b = new byte[8192]; int n, total = 0;
        try { while ((n = in.read(b)) != -1) { total += n; if (total > max) throw new IOException("File too large for in-memory read"); out.write(b,0,n); } }
        finally { in.close(); }
        return out.toByteArray();
    }

    private String jsonEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    private void zipDirectory(File root, File destination) throws IOException {
        if (destination.exists()) destination.delete();
        ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(destination)));
        List<File> list = new ArrayList<File>(); walk(root, list);
        byte[] b = new byte[BUFFER_SIZE];
        try {
            for (int i = 0; i < list.size(); i++) {
                File f = list.get(i); if (!f.isFile()) continue;
                ZipEntry entry = new ZipEntry(relativeTo(root, f)); zos.putNextEntry(entry);
                InputStream in = new BufferedInputStream(new FileInputStream(f)); int n;
                try { while ((n = in.read(b)) != -1) zos.write(b, 0, n); }
                finally { in.close(); }
                zos.closeEntry();
            }
        } finally { zos.close(); }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.loadUrl("javascript:window.PortYouBack && window.PortYouBack();");
        else super.onBackPressed();
    }
}
