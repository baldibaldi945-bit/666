(function () {
  'use strict';
  var files = { vChart: null, vMeta: null, fmData: null, fmEvents: null, fmScene: null, chartResult: null, fnmmResult: null, audioResult: null, atlasResult: null, fnmmSpriteResult: null, btaResult: null, psychFlip: null, characterResult: null, charIconResult: null, notesAtlasResult: null, shaderMaskResult: null };
  var currentArchive = [];
  var activeModRoot = '';
  var lastLua = '';
  var q = function (id) { return document.getElementById(id); };

  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, function (c) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]); }); }
  function showScreen(name) {
    var nodes = document.querySelectorAll('.screen'), i;
    for (i = 0; i < nodes.length; i++) nodes[i].className = 'screen';
    var target = q(name + 'Screen'); if (target) target.className = 'screen active';
    if (name === 'settings') {
      if (!window.__portyouSettingsSeen) { q('settingsArtwork').src = 'assets/ui/settings/1.png'; window.__portyouSettingsSeen = true; }
      else randomSettingsArt();
      showSettingsView('main', false);
    }
    if (name === 'home') q('homeArtwork').src = 'assets/ui/home/1.png';
    playTap();
    window.scrollTo(0, 0);
  }
  function playTap() {
    if (q('tapOn') && !q('tapOn').checked) return;
    var a = q('tapSound'); if (!a) return;
    try { a.currentTime = 0; var p = a.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }
  function setStatus(node, text, isError) {
    if (!node) return; node.textContent = text; node.style.color = isError ? '#ffd0d0' : '';
  }
  function readTextFile(file, callback) {
    if (!file) return callback(new Error('No file selected.'));
    var r = new FileReader(); r.onload = function (e) { callback(null, String(e.target.result)); };
    r.onerror = function () { callback(new Error('Could not read file.')); }; r.readAsText(file);
  }
  function readBuffer(file, callback) {
    if (!file) return callback(new Error('No file selected.'));
    var r = new FileReader(); r.onload = function (e) { callback(null, e.target.result); };
    r.onerror = function () { callback(new Error('Could not read binary file.')); }; r.readAsArrayBuffer(file);
  }
  function downloadBlob(blob, name) {
    if (window.Android && window.Android.writeBase64File && blob && window.FileReader) {
      var r = new FileReader(); r.onload = function (e) {
        var data = String(e.target.result).split(',')[1];
        try { window.Android.writeBase64File(name, data); } catch (ex) { alert('Save error: ' + ex); }
      }; r.readAsDataURL(blob); return;
    }
    var url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); document.body.removeChild(a); }, 800);
  }
  function downloadText(text, name, mime) { downloadBlob(new Blob([text], {type: mime || 'application/json'}), name); }
  function parseJson(text, label) { try { return JSON.parse(text); } catch (e) { throw new Error(label + ' is not valid JSON: ' + e.message); } }
  function randomSettingsArt() {
    // The user's setting artwork instructions reserve random rotation for images 2–5 only.
    var n = 2 + Math.floor(Math.random() * 4);
    q('settingsArtwork').src = 'assets/ui/settings/' + n + '.png';
  }
  var aboutText = {
    ar: 'مرحباً بك في PortYou Studio. التطبيق مخصص لمساعدة نقل مودات V-Slice وFunkin’ Maker إلى Psych Engine 1.0.4. يسهّل التحويل، مع احتمال وجود أخطاء أو موارد ناقصة، ويسمح بمراجعة الشارتات والستاجات وإضافة الأسهم وأدوات أخرى. التطبيق من صنع AxelzeroX23. راجع تقرير التحويل واختبر المود داخل المحرك قبل اعتماده. إذا واجهت مشكلة، يمكنك مراسلتي عبر الحسابات المتاحة. شكراً! (≧▽≦)',
    sy: 'أهلاً في PortYou Studio! هالتطبيق معمول ليساعدك تنقل مودات V-Slice وFunkin’ Maker إلى Psych Engine 1.0.4. بيسهّل التحويل، بس ممكن تضل أخطاء أو ملفات ناقصة، فراجع الشارتات والمراحل والأحداث وجرب المود بالمحرك قبل ما تعتمده. التطبيق من صنع AxelzeroX23. شكراً لدعمكم! (≧▽≦)',
    'ar-SA': 'مرحباً بك في PortYou Studio. يساعدك التطبيق على تجهيز مودات V-Slice وFunkin’ Maker لنقلها إلى Psych Engine 1.0.4. راجع تقرير التحويل وافحص الشخصيات والمراحل والأحداث والنوتات، ثم اختبر المود داخل المحرك قبل اعتماده. تطوير AxelzeroX23. شكراً لدعمكم!',
    'pt-BR': 'Bem-vindo ao PortYou Studio! O aplicativo ajuda a preparar mods de V-Slice e Funkin’ Maker para o Psych Engine 1.0.4. Confira o relatório, revise personagens, fases, eventos e charts e teste o mod no próprio engine antes de publicar. Desenvolvido por AxelzeroX23. Obrigado por apoiar o projeto!',
    fr: 'Bienvenue dans PortYou Studio. Cette application aide à convertir les mods V-Slice et Funkin’ Maker vers Psych Engine 1.0.4. Elle simplifie le portage, mais des erreurs ou des ressources manquantes restent possibles. Vérifiez les charts, les stages et les événements, puis testez le mod dans le moteur avant de le publier. Application créée par AxelzeroX23. Merci !',
    th: 'ยินดีต้อนรับสู่ PortYou Studio แอปนี้ช่วยเตรียมม็อด V-Slice และ Funkin’ Maker เพื่อแปลงไปยัง Psych Engine 1.0.4 การแปลงอาจมีข้อผิดพลาดหรือไฟล์บางส่วนขาดหาย โปรดตรวจสอบชาร์ต ฉาก และอีเวนต์ แล้วทดสอบในเอนจินก่อนใช้งาน แอปสร้างโดย AxelzeroX23 ขอบคุณ!',
    ja: 'PortYou Studio へようこそ。このアプリは V-Slice と Funkin’ Maker の MOD を Psych Engine 1.0.4 向けに変換する作業を支援します。変換後にエラーや不足ファイルが残る場合があります。チャート、ステージ、イベントを確認し、エンジン内でテストしてから使用してください。作者：AxelzeroX23。ありがとうございます。'
  };
  function showSettingsView(view, changeArtwork) {
    var panels = ['settingsMainPanel','languagePanel','socialPanel','soundPanel','settingsBackPanel'];
    for (var i = 0; i < panels.length; i++) if (q(panels[i])) q(panels[i]).hidden = true;
    q('aboutArtwork').hidden = true;
    var hotspots = document.querySelectorAll('.settingsHotspot');
    for (var h = 0; h < hotspots.length; h++) hotspots[h].style.display = view === 'main' ? 'block' : 'none';

    var artNumber = { languages:6, sound:10, youtube:11, instagram:12, about:9 };
    if (view === 'main') {
      if (changeArtwork) randomSettingsArt();
      q('settingsMainPanel').hidden = false;
      return;
    }

    if (artNumber[view]) q('settingsArtwork').src = 'assets/ui/settings/' + artNumber[view] + '.png';
    q('settingsBackPanel').hidden = false;
    if (view === 'languages') q('languagePanel').hidden = false;
    else if (view === 'about') {
      q('aboutArtwork').hidden = false;
      var lang = q('language') ? q('language').value : 'ar';
      q('aboutDescription').textContent = aboutText[lang] || aboutText.ar;
    } else if (view === 'sound') q('soundPanel').hidden = false;
    else if (view === 'youtube' || view === 'instagram') {
      q('socialPanel').hidden = false;
      q('socialTitle').textContent = view === 'youtube' ? 'YouTube' : 'Instagram';
      q('socialDescription').textContent = view === 'youtube' ? 'القناة الرسمية لصانع PortYou Studio.' : 'حساب Instagram الخاص بصانع التطبيق.';
      q('developerYoutubeLink').hidden = view !== 'youtube';
      q('instagramAccountLink').hidden = view !== 'instagram';
      q('missingYoutubeMessage').hidden = true;
    }
  }
  q('languageHotspot').onclick = function () { showSettingsView('languages'); };
  q('aboutHotspot').onclick = function () { showSettingsView('about'); };
  q('soundHotspot').onclick = function () { showSettingsView('sound'); };
  q('youtubeHotspot').onclick = function () { showSettingsView('youtube'); };
  q('instagramHotspot').onclick = function () { showSettingsView('instagram'); };
  q('showFriends').onclick = function () { showScreen('friends'); };

  // Keep the supplied numbered editor drawings intact and browse them as visual guides.
  var artStepButtons = document.querySelectorAll('[data-art-src]');
  for (var artIndex = 0; artIndex < artStepButtons.length; artIndex++) (function (button) {
    button.onclick = function () {
      var target = q(button.getAttribute('data-art-target'));
      if (target) target.src = button.getAttribute('data-art-src');
    };
  }(artStepButtons[artIndex]));

  // Main navigation and original-art hit zones.
  document.addEventListener('click', function (e) {
    var el = e.target, name;
    while (el && !el.getAttribute('data-screen')) el = el.parentNode;
    if (el && (name = el.getAttribute('data-screen'))) { showScreen(name); }
  });
  q('backBtn').onclick = function () { showScreen('home'); };
  q('settingsBtn').onclick = function () { showScreen('settings'); };
  q('settingsArtwork').onclick = function () {}; 
  q('homeArtwork').addEventListener('load', function () {});
  var homeArtButtons = document.querySelectorAll('[data-art]');
  for (var ha = 0; ha < homeArtButtons.length; ha++) (function (button) {
    var change = function () { q('homeArtwork').src = 'assets/ui/home/' + button.getAttribute('data-art'); };
    button.addEventListener('mouseover', change); button.addEventListener('focus', change); button.addEventListener('click', change);
    button.addEventListener('mouseout', function () { if (!button.matches || !button.matches(':focus')) q('homeArtwork').src = 'assets/ui/home/1.png'; });
    button.addEventListener('blur', function () { q('homeArtwork').src = 'assets/ui/home/1.png'; });
  }(homeArtButtons[ha]));

  // Keep the supplied background music alive only while the app is visible.
  function resumeMusic() {
    if (q('musicOn') && q('musicOn').checked) {
      var m = q('loopMusic'); try { var p = m.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
    }
  }
  document.addEventListener('visibilitychange', function () {
    var m = q('loopMusic');
    if (document.hidden) { try { m.pause(); } catch (e) {} }
    else resumeMusic();
  });
  window.onHostPause = function () { try { q('loopMusic').pause(); q('tapSound').pause(); } catch (e) {} };
  window.onHostResume = function () { resumeMusic(); };
  q('musicOn').onchange = function () {
    var m = q('loopMusic');
    if (q('musicOn').checked) resumeMusic(); else { try { m.pause(); } catch (e) {} }
  };
  document.body.addEventListener('touchstart', function () { if (!q('loopMusic').paused) return; resumeMusic(); }, { once: true });
  document.body.addEventListener('click', function () { if (q('loopMusic').paused) resumeMusic(); }, { once: true });

  // Standalone V-Slice chart converter.
  q('vChartFile').onchange = function () { files.vChart = this.files[0] || null; };
  q('vMetaFile').onchange = function () { files.vMeta = this.files[0] || null; };
  q('convertVslice').onclick = function () {
    if (!files.vChart || !files.vMeta) return alert('اختر Chart JSON و Metadata JSON أولاً.');
    readTextFile(files.vChart, function (err, a) {
      if (err) return setStatus(q('vWarnings'), err.message, true);
      readTextFile(files.vMeta, function (err2, b) {
        if (err2) return setStatus(q('vWarnings'), err2.message, true);
        try {
          var result = PortYouConverters.convertVSlice(parseJson(a, 'Chart'), parseJson(b, 'Metadata'), {
            difficulty: q('vDiff').value, song: q('vSong').value, bpm: Number(q('vBpm').value), flipSides: q('vFlip').checked
          });
          files.chartResult = result.chart;
          q('vOutput').value = JSON.stringify(result.chart, null, 2);
          q('downloadChart').disabled = false;
          setStatus(q('vWarnings'), (result.warnings.length ? result.warnings.join('\n') : 'تم التحويل دون أحداث غير معروفة.') + '\n\nملاحظة: راجع جهة النوتات داخل المحرك. زر القلب يبدّل 0..3 مع 4..7 فقط.', false);
        } catch (ex) { setStatus(q('vWarnings'), ex.message, true); }
      });
    });
  };
  q('downloadChart').onclick = function () { if (files.chartResult) downloadText(JSON.stringify(files.chartResult, null, 2), 'converted-chart.json'); };
  q('psychFlipFile').onchange = function () { files.psychFlip = this.files[0] || null; };
  q('flipPsychChart').onclick = function () {
    if (!files.psychFlip) return alert('اختر ملف Psych chart JSON أولاً.');
    readTextFile(files.psychFlip, function (err, text) {
      if (err) return setStatus(q('psychFlipReport'), err.message, true);
      try {
        var chart = parseJson(text, 'Psych chart'), song = chart.song || chart;
        if (!song.notes || Object.prototype.toString.call(song.notes) !== '[object Array]') throw new Error('هذا الملف لا يحتوي song.notes بصيغة Psych المعتادة.');
        var count = 0;
        for (var si = 0; si < song.notes.length; si++) {
          var list = song.notes[si].sectionNotes || [];
          for (var ni = 0; ni < list.length; ni++) if (list[ni] && list[ni].length > 1 && Number(list[ni][1]) >= 0 && Number(list[ni][1]) <= 7) count++;
        }
        PortYouConverters.applySideFlip(song.notes, true);
        files.psychFlipResult = chart;
        q('downloadPsychFlip').disabled = false;
        setStatus(q('psychFlipReport'), 'تم قلب جهة ' + count + ' نوتة. لم يتم تغيير الأوقات أو الـSustain أو الأحداث أو بيانات الأغنية الأخرى.');
      } catch (ex) { files.psychFlipResult = null; q('downloadPsychFlip').disabled = true; setStatus(q('psychFlipReport'), ex.message, true); }
    });
  };
  q('downloadPsychFlip').onclick = function () {
    if (files.psychFlipResult) downloadText(JSON.stringify(files.psychFlipResult, null, 2), 'psych-chart-side-flipped.json');
  };

  // Standalone Funkin Maker converter.
  q('fmData').onchange = function () { files.fmData = this.files[0] || null; };
  q('fmEvents').onchange = function () { files.fmEvents = this.files[0] || null; };
  q('fmScene').onchange = function () { files.fmScene = this.files[0] || null; };
  q('convertFnmm').onclick = function () {
    if (!files.fmData || !files.fmEvents || !files.fmScene) return alert('اختر data.json و events.json و scene.json.');
    var remaining = 3, texts = {}, error = null;
    [['fmData', files.fmData], ['fmEvents', files.fmEvents], ['fmScene', files.fmScene]].forEach(function (entry) {
      readTextFile(entry[1], function (err, text) {
        if (err) error = err;
        else texts[entry[0]] = text;
        remaining--;
        if (!remaining) {
          if (error) return setStatus(q('fmWarnings'), error.message, true);
          try {
            var result = PortYouConverters.convertFunkinMaker(parseJson(texts.fmData, 'data.json'),
              parseJson(texts.fmEvents, 'events.json'), parseJson(texts.fmScene, 'scene.json'), {flipSides: q('fmFlip').checked});
            files.fnmmResult = result;
            q('fmOutput').value = JSON.stringify({psychChart: result.chart, stage: result.stage, spritePlan: result.spritePlan}, null, 2);
            q('downloadFnmm').disabled = false;
            setStatus(q('fmWarnings'), (result.warnings.length ? result.warnings.join('\n') : 'تمت قراءة الشارت والستاج.') + '\nملاحظة: صور الشخصيات تحتاج إعادة تجميع الأطالس وتعيين أسماء الحركات يدوياً قبل اعتمادها.', false);
          } catch (ex) { setStatus(q('fmWarnings'), ex.message, true); }
        }
      });
    });
  };
  q('downloadFnmm').onclick = function () {
    if (!files.fnmmResult) return;
    downloadText(JSON.stringify(files.fnmmResult.chart, null, 2), 'converted-chart.json');
    setTimeout(function () { downloadText(JSON.stringify(files.fnmmResult.stage, null, 2), 'converted-stage.json'); }, 250);
  };

  // Sprite map / Sparrow sheet parsing and extraction.
  q('readAtlas').onclick = function () {
    var png = q('atlasPng').files[0], meta = q('atlasMeta').files[0];
    if (!png || !meta) return alert('اختر PNG وملف XML أو JSON.');
    readTextFile(meta, function (err, text) {
      if (err) return setStatus(q('atlasInfo'), err.message, true);
      var frames;
      try { frames = /\.xml$/i.test(meta.name) ? PortYouSprites.parseSparrowXml(text) : PortYouSprites.parseSpritemapJson(parseJson(text, 'Atlas metadata')); }
      catch (ex) { return setStatus(q('atlasInfo'), ex.message, true); }
      if (!frames.length) return setStatus(q('atlasInfo'), 'لم يتم العثور على أي Rect/Frame في هذا الملف. صيغة JSON قد تحتاج mapping مخصص.', true);
      PortYouSprites.imageFromFile(png, function (err2, image) {
        if (err2) return setStatus(q('atlasInfo'), err2.message, true);
        PortYouSprites.cutFrames(image, frames, {columns: Number(q('atlasCols').value), imageName: q('atlasName').value}, function (err3, result) {
          if (err3) return setStatus(q('atlasInfo'), err3.message, true);
          files.atlasResult = result; q('downloadAtlas').disabled = false;
          setStatus(q('atlasInfo'), 'تم التعرف على ' + frames.length + ' فريم. حجم الأطلس الجديد: ' + result.width + ' × ' + result.height + '.');
        });
      });
    });
  };
  q('downloadAtlas').onclick = function () {
    if (!files.atlasResult) return;
    var b = dataUrlToBlob(files.atlasResult.pngDataUrl);
    downloadBlob(b, q('atlasName').value + '.png');
    setTimeout(function () { downloadText(files.atlasResult.xml, q('atlasName').value + '.xml', 'application/xml'); }, 250);
  };
  // Offline BTA/Spritemap animation composition to normal Sparrow atlas.
  q('buildBta').onclick = function () {
    var png = q('atlasPng').files[0], smFile = q('btaMapMeta').files[0], animFile = q('btaAnimMeta').files[0];
    if (!png || !smFile || !animFile) return alert('اختر PNG + Spritemap JSON + Animation JSON.');
    var pending = 2, texts = {}, readError = null;
    [[ 'sm', smFile ], [ 'anim', animFile ]].forEach(function (it) {
      readTextFile(it[1], function (err, value) {
        if (err) readError = err; else texts[it[0]] = value;
        pending--;
        if (!pending) {
          if (readError) return setStatus(q('btaInfo'), readError.message, true);
          try {
            var sm = parseJson(texts.sm, 'Spritemap JSON'), anim = parseJson(texts.anim, 'Animation JSON');
            PortYouSprites.imageFromFile(png, function (imgErr, image) {
              if (imgErr) return setStatus(q('btaInfo'), imgErr.message, true);
              PortYouSprites.renderBtaToSparrow(image, sm, anim, { imageName: q('btaName').value || 'bta_character', columns: Number(q('btaCols').value) || 4, maxCanvasSide: 4096 }, function (renderErr, result) {
                if (renderErr) return setStatus(q('btaInfo'), renderErr.message, true);
                var animRows = result.animations.map(function (a) { return { name: a.name, prefix: a.name, fps: a.fps, loop: a.loop, indices: a.indices, x: 0, y: 0 }; });
                var char = PortYouSprites.buildCharacterJson({ image: 'characters/' + (q('btaName').value || 'bta_character'), animations: animRows, healthIcon: q('btaName').value || 'face' });
                files.btaResult = { atlas: result, character: char, name: q('btaName').value || 'bta_character' };
                q('downloadBta').disabled = false;
                setStatus(q('btaInfo'), 'اكتمل تركيب ' + result.frameCount + ' فريم ضمن ' + result.animations.length + ' حركة. الأبعاد: ' + result.width + '×' + result.height + '.');
              });
            });
          } catch (ex) { setStatus(q('btaInfo'), ex.message, true); }
        }
      });
    });
  };
  q('downloadBta').onclick = function () {
    if (!files.btaResult) return;
    var r = files.btaResult;
    downloadBlob(dataUrlToBlob(r.atlas.pngDataUrl), r.name + '.png');
    setTimeout(function () { downloadText(r.atlas.xml, r.name + '.xml', 'application/xml'); }, 250);
    setTimeout(function () { downloadText(JSON.stringify(r.character, null, 2), r.name + '.json'); }, 500);
  };
  // Offline Funkin Maker strip builder. Source order follows numbered PNGs and sprite.json data rows.
  q('buildFnmmSprite').onclick = function () {
    var metaFile = q('fnmmSpriteMeta').files[0], imageFiles = Array.prototype.slice.call(q('fnmmSpriteImages').files || []);
    if (!metaFile || !imageFiles.length) return alert('اختر sprite.json وصورة PNG واحدة على الأقل.');
    imageFiles.sort(function (a, b) {
      var an = Number(a.name.replace(/\.png$/i, '')), bn = Number(b.name.replace(/\.png$/i, ''));
      return (isNaN(an) ? 0 : an) - (isNaN(bn) ? 0 : bn);
    });
    readTextFile(metaFile, function (err, text) {
      if (err) return setStatus(q('fnmmSpriteInfo'), err.message, true);
      try {
        var meta = parseJson(text, 'sprite.json');
        PortYouSprites.buildFnmmAtlas(imageFiles, meta, { imageName: q('fnmmSpriteName').value || 'sprite', columns: Number(q('fnmmSpriteCols').value) || 4 }, function (buildError, atlas) {
          if (buildError) return setStatus(q('fnmmSpriteInfo'), buildError.message, true);
          var anims = atlas.animations.map(function (a) { return { name: a.name, prefix: a.name, fps: a.fps, loop: a.loop, indices: a.indices, x: a.offsetX, y: a.offsetY }; });
          var charJson = PortYouSprites.buildCharacterJson({ image: 'characters/' + (q('fnmmSpriteName').value || 'sprite'), animations: anims,
            scale: Number((meta.data && meta.data[0] && meta.data[0].scale) || 1), healthIcon: q('fnmmSpriteName').value || 'face' });
          files.fnmmSpriteResult = { atlas: atlas, character: charJson, name: q('fnmmSpriteName').value || 'sprite' };
          q('downloadFnmmSprite').disabled = false;
          setStatus(q('fnmmSpriteInfo'), 'تم تقسيم ' + atlas.frameCount + ' فريم إلى أطلس ' + atlas.width + '×' + atlas.height + '. عدد الحركات المقترحة: ' + atlas.animations.length + '. افحص أسماء الحركات والـOffsets قبل اعتماد JSON.' + (atlas.warnings && atlas.warnings.length ? '\n' + atlas.warnings.join('\n') : ''));
        });
      } catch (ex) { setStatus(q('fnmmSpriteInfo'), ex.message, true); }
    });
  };
  q('downloadFnmmSprite').onclick = function () {
    if (!files.fnmmSpriteResult) return;
    var r = files.fnmmSpriteResult;
    downloadBlob(dataUrlToBlob(r.atlas.pngDataUrl), r.name + '.png');
    setTimeout(function () { downloadText(r.atlas.xml, r.name + '.xml', 'application/xml'); }, 250);
    setTimeout(function () { downloadText(JSON.stringify(r.character, null, 2), r.name + '.json'); }, 500);
  };
  function dataUrlToBlob(url) {
    var parts = url.split(','), mime = parts[0].match(/:(.*?);/)[1], raw = atob(parts[1]), len = raw.length, u8 = new Uint8Array(len);
    for (var i = 0; i < len; i++) u8[i] = raw.charCodeAt(i);
    return new Blob([u8], {type: mime});
  }

  // Merge classic note atlas + optional detached hold atlas while retaining XML frame metadata.
  function loadImageFile(file, callback) { PortYouSprites.imageFromFile(file, callback); }
  function mergeXmlContent(xmlText, offsetX, prefix) {
    var tags = String(xmlText || '').match(/<SubTexture\b[^>]*\/?\s*>/g) || [], out = [];
    for (var i = 0; i < tags.length; i++) {
      var tag = tags[i], xMatch = tag.match(/\bx="([^"]+)"/), nameMatch = tag.match(/\bname="([^"]+)"/);
      if (!nameMatch) continue;
      var x = xMatch ? Number(xMatch[1]) : 0;
      tag = tag.replace(/\bname="([^"]+)"/, 'name="' + (prefix || '') + '$1"');
      if (xMatch) tag = tag.replace(/\bx="([^"]+)"/, 'x="' + (x + offsetX) + '"');
      else tag = tag.replace(/<SubTexture\b/, '<SubTexture x="' + offsetX + '"');
      out.push(tag);
    }
    return out;
  }
  q('buildNoteAtlas').onclick = function () {
    var noteFile = q('notePng').files[0], noteXmlFile = q('noteXml').files[0], holdFile = q('holdPng').files[0], holdXmlFile = q('holdXml').files[0];
    if (!noteFile || !noteXmlFile) return alert('اختر Notes PNG وXML أولاً.');
    var pending = holdFile ? 4 : 2, loaded = {}, failed = null;
    function finishRead() {
      if (failed) return setStatus(q('notesResult'), failed.message, true);
      var baseImage = loaded.noteImage, holdImage = loaded.holdImage || null;
      var canvas = document.createElement('canvas'), width = baseImage.width + (holdImage ? holdImage.width : 0), height = Math.max(baseImage.height, holdImage ? holdImage.height : 0);
      if (width > 4096 || height > 4096) return setStatus(q('notesResult'), 'الأطلس المدمج يتجاوز حد Canvas الآمن 4096px.', true);
      canvas.width = width; canvas.height = height;
      var ctx = canvas.getContext('2d'); ctx.drawImage(baseImage, 0, 0);
      if (holdImage) ctx.drawImage(holdImage, baseImage.width, 0);
      var noteXmlText = loaded.noteXmlText || '', tags = mergeXmlContent(noteXmlText, 0, '');
      if (holdImage) {
        if (loaded.holdXmlText) tags = tags.concat(mergeXmlContent(loaded.holdXmlText, baseImage.width, 'hold_'));
        else tags.push('<SubTexture name="hold_piece" x="' + baseImage.width + '" y="0" width="' + holdImage.width + '" height="' + holdImage.height + '"/>');
      }
      var skinName = String(q('noteSkinName').value || 'NOTE_assets-ported').replace(/[^a-zA-Z0-9_-]/g, '_');
      var xmlOut = '<?xml version="1.0" encoding="utf-8"?>\n<TextureAtlas imagePath="' + skinName + '.png">\n' + tags.join('\n') + '\n</TextureAtlas>';
      files.notesAtlasResult = { pngDataUrl: canvas.toDataURL('image/png'), xml: xmlOut, name: skinName,
        config: { alpha: Number(q('noteAlpha').value), holdLayer: q('holdOrder').value, atlas: skinName + '.png', xml: skinName + '.xml', holdMerged: !!holdImage } };
      setStatus(q('notesResult'), 'تم تجهيز أطلس ' + skinName + ' بحجم ' + width + '×' + height + '. ' + tags.length + ' إطار. ترتيب Hold المطلوب: ' + q('holdOrder').value + '.\nملاحظة: تم دمج البكسلات ومواضع XML؛ ترتيب رسم الـsustain داخل Psych يحتاج اختباراً داخل المحرك ولا يتحكم به XML وحده.');
    }
    function readText(file, key) { if (!file) { loaded[key] = ''; return doneOne(); } readTextFile(file, function (e, t) { if (e) failed = e; else loaded[key] = t; doneOne(); }); }
    function doneOne() { pending--; if (pending === 0) finishRead(); }
    readText(noteXmlFile, 'noteXmlText');
    if (holdFile) {
      loadImageFile(noteFile, function (e, im) { if (e) failed=e; else loaded.noteImage=im; doneOne(); });
      loadImageFile(holdFile, function (e, im) { if (e) failed=e; else loaded.holdImage=im; doneOne(); });
      if (holdXmlFile) readText(holdXmlFile, 'holdXmlText');
      else { loaded.holdXmlText = ''; doneOne(); }
    } else {
      // Without a detached hold atlas there is no need to merge or re-pack the source.
      loadImageFile(noteFile, function (e, im) { if (e) failed=e; else loaded.noteImage=im; doneOne(); });
    }
  };
  q('saveNotesConfig').onclick = function () {
    if (!files.notesAtlasResult) return alert('اضغط «دمج Atlas الأسهم وHold» أولاً.');
    var r = files.notesAtlasResult;
    downloadBlob(dataUrlToBlob(r.pngDataUrl), r.name + '.png');
    setTimeout(function () { downloadText(r.xml, r.name + '.xml', 'application/xml'); }, 250);
    setTimeout(function () { downloadText(JSON.stringify(r.config, null, 2), 'portyou-note-skin.json'); }, 500);
    if (activeModRoot && window.Android) {
      writeDataUrl(activeModRoot + '/images/noteSkins/' + r.name + '.png', r.pngDataUrl);
      nativeWrite(activeModRoot + '/images/noteSkins/' + r.name + '.xml', r.xml);
      nativeWrite(activeModRoot + '/data/portyou-note-skin.json', JSON.stringify(r.config,null,2));
    }
    q('notesResult').textContent += '\nتم تجهيز PNG/XML/JSON للتنزيل.' + (activeModRoot ? '\nونسخها إلى مجلد noteSkins للمود.' : '') + ' ترتيب رسم الـHold يحتاج اختباراً داخل Psych.';
  };

  // Character metadata editor: offsets and health bar colour are emitted as Psych fields.
  q('charSourceJson').onchange = function () {
    var f = this.files[0]; if (!f) return;
    readTextFile(f, function (err, text) {
      if (err) return setStatus(q('characterInfo'), err.message, true);
      try {
        var c = parseJson(text, 'Character JSON');
        q('charId').value = c.name || f.name.replace(/\.json$/i, '');
        q('charHealthIcon').value = c.healthicon || 'face'; q('charImagePath').value = c.image || 'characters/' + q('charId').value;
        q('charScale').value = c.scale || 1; q('charAlpha').value = c._portyou && c._portyou.alpha !== undefined ? c._portyou.alpha : 1;
        q('charPosX').value = (c.position || [0,0])[0] || 0; q('charPosY').value = (c.position || [0,0])[1] || 0;
        q('charCamX').value = (c.camera_position || [0,0])[0] || 0; q('charCamY').value = (c.camera_position || [0,0])[1] || 0;
        q('charSingDuration').value = c.sing_duration || 4; q('charFlipX').value = c.flip_x ? 'true' : 'false';
        var hc = c.healthbar_colors || [255,0,0]; q('charHealthR').value=hc[0]; q('charHealthG').value=hc[1]; q('charHealthB').value=hc[2];
        q('charAnimations').value = JSON.stringify((c.animations || []).map(function(a){ return {anim:a.anim,name:a.name,fps:a.fps,loop:a.loop,indices:a.indices || [],offsets:a.offsets || [a.x || 0,a.y || 0]}; }), null, 2);
        setStatus(q('characterInfo'), 'تم تحميل بيانات الشخصية. افحص prefixes والـoffsets قبل البناء.');
      } catch (ex) { setStatus(q('characterInfo'), ex.message, true); }
    });
  };
  q('buildCharacterJson').onclick = function () {
    try {
      var anims = parseJson(q('charAnimations').value, 'Animations JSON');
      if (Object.prototype.toString.call(anims) !== '[object Array]') throw new Error('قائمة الحركات يجب أن تكون Array.');
      var normalAnims = anims.map(function (a) {
        var off = a.offsets || [a.x || 0, a.y || 0];
        return { anim:a.anim || a.name || 'idle', prefix:a.name || a.prefix || a.anim || 'idle', fps:Number(a.fps)||24,
          loop:!!a.loop, indices:a.indices || [], x:Number(off[0])||0, y:Number(off[1])||0 };
      });
      var id = String(q('charId').value || 'new-character').replace(/[^a-zA-Z0-9_-]/g,'_');
      var healthColors = [Number(q('charHealthR').value)||0, Number(q('charHealthG').value)||0, Number(q('charHealthB').value)||0].map(function(n){return Math.max(0,Math.min(255,n));});
      var character = PortYouSprites.buildCharacterJson({ image:q('charImagePath').value || ('characters/' + id), animations:normalAnims,
        scale:Number(q('charScale').value)||1, alpha:Number(q('charAlpha').value), healthIcon:q('charHealthIcon').value || id,
        position:[Number(q('charPosX').value)||0,Number(q('charPosY').value)||0], cameraPosition:[Number(q('charCamX').value)||0,Number(q('charCamY').value)||0],
        singDuration:Number(q('charSingDuration').value)||4, flipX:q('charFlipX').value==='true', healthbarColors:healthColors });
      character.name = id;
      var lua = '-- PortYou character helper for Psych Engine 1.0.4\n-- Review the target character role before using.\nfunction onCreatePost()\n' +
        "  if dadName == '" + id + "' then setProperty('dad.alpha', " + Math.max(0,Math.min(1,Number(q('charAlpha').value))) + ') end\n' +
        "  if boyfriendName == '" + id + "' then setProperty('boyfriend.alpha', " + Math.max(0,Math.min(1,Number(q('charAlpha').value))) + ') end\n' +
        "  if gfName == '" + id + "' then setProperty('gf.alpha', " + Math.max(0,Math.min(1,Number(q('charAlpha').value))) + ') end\nend\n';
      files.characterResult = { json:character, lua:lua, id:id }; q('downloadCharacterJson').disabled=false;
      setStatus(q('characterInfo'), 'تم إنشاء Character JSON مع ' + normalAnims.length + ' حركة وألوان healthbar [' + healthColors.join(',') + ']. تم إنشاء Lua helper للشفافية.');
    } catch (ex) { files.characterResult=null; q('downloadCharacterJson').disabled=true; setStatus(q('characterInfo'), ex.message, true); }
  };
  q('downloadCharacterJson').onclick = function () {
    if (!files.characterResult) return;
    downloadText(JSON.stringify(files.characterResult.json,null,2), files.characterResult.id + '.json');
    setTimeout(function(){downloadText(files.characterResult.lua, files.characterResult.id + '.lua','text/plain');},250);
    if (activeModRoot && window.Android) {
      nativeWrite(activeModRoot + '/characters/' + files.characterResult.id + '.json', JSON.stringify(files.characterResult.json,null,2));
      nativeWrite(activeModRoot + '/characters/' + files.characterResult.id + '.lua', files.characterResult.lua);
      setStatus(q('characterInfo'), q('characterInfo').textContent + '\nتم أيضاً نسخ JSON وLua إلى ' + activeModRoot + '/characters داخل مشروع المود.');
    }
  };
  q('buildCharIcon').onclick = function () {
    var selected = Array.prototype.slice.call(q('charIconImages').files || []);
    if (!selected.length || selected.length > 3) return alert('اختر من صورة إلى ثلاث صور للأيقونة.');
    var images = [], index = 0;
    function next() {
      if (index >= selected.length) {
        var h=0,w=0; for(var i=0;i<images.length;i++){h=Math.max(h,images[i].height);w+=images[i].width;}
        if (w>4096 || h>4096) return setStatus(q('charIconInfo'),'أبعاد الأيقونة تتجاوز حد 4096px.',true);
        var c=document.createElement('canvas');c.width=w;c.height=h;var ctx=c.getContext('2d'),x=0;
        for(i=0;i<images.length;i++){ctx.drawImage(images[i],x,0);x+=images[i].width;}
        files.charIconResult=c.toDataURL('image/png');q('downloadCharIcon').disabled=false;
        setStatus(q('charIconInfo'),'تم دمج ' + images.length + ' صورة دون تغيير أبعادها الأصلية: ' + w + '×' + h + '.');return;
      }
      loadImageFile(selected[index++],function(e,im){if(e)return setStatus(q('charIconInfo'),e.message,true);images.push(im);next();});
    }
    next();
  };
  q('downloadCharIcon').onclick=function(){if(!files.charIconResult)return;var iconName='icon-' + (q('charId').value||'character') + '.png';downloadBlob(dataUrlToBlob(files.charIconResult),iconName);if(activeModRoot&&window.Android)writeDataUrl(activeModRoot+'/images/icons/'+iconName,files.charIconResult);};

  // Offline simultaneous audio mixing.
  q('mixAudio').onclick = function () {
    var list = q('audioFiles').files;
    if (!list || !list.length) return alert('اختر ملف MP3 أو WAV واحداً على الأقل.');
    setStatus(q('audioInfo'), list.length === 1 ? 'جارٍ تحويل الصوت إلى OGG Vorbis…' : 'جارٍ مزج المسارات بالتزامن ثم ترميزها OGG…');
    q('downloadOgg').disabled = true;
    PortYouAudio.mixFiles(Array.prototype.slice.call(list), {}, function (err, result) {
      if (err) return setStatus(q('audioInfo'), err.message, true);
      files.audioResult = result;
      q('downloadOgg').disabled = false;
      setStatus(q('audioInfo'), 'اكتمل التحويل: ' + result.trackCount + ' مسارات · ' + result.duration.toFixed(2) + ' ثانية · OGG Vorbis · ' + result.sampleRate + ' Hz.');
    });
  };
  q('downloadOgg').onclick = function () {
    if (files.audioResult) downloadBlob(files.audioResult.ogg, files.audioResult.trackCount === 1 ? 'converted-audio.ogg' : 'mixed-audio.ogg');
  };

  // Haxe/HScript translator module: rule-based and conservative; unsupported code is retained as TODO.
  q('haxeFile').onchange = function () {
    var f = this.files[0]; if (!f) return;
    readTextFile(f, function (err, text) { if (err) return setStatus(q('haxeReport'), err.message, true); q('haxeInput').value = text; });
  };
  q('convertHaxe').onclick = function () {
    if (!window.PortYouHaxe || !window.PortYouHaxe.translate) return setStatus(q('haxeReport'), 'وحدة تحويل Haxe غير محمّلة. أعد مزامنة ملفات التطبيق ثم أعد البناء.', true);
    var r = window.PortYouHaxe.translate(q('haxeInput').value);
    lastLua = r.lua; q('luaOutput').value = r.lua;
    q('downloadLua').disabled = false;
    var summary = 'تم تحويل ' + r.mappedCount + ' عبارة من ' + r.sourceLines + ' سطراً. عدد نقاط المراجعة: ' + r.warnings.length + '\n';
    summary += r.warnings.length ? r.warnings.join('\n') : 'لم تظهر أسطر غير معروفة في العينة.';
    summary += '\n\nالقواعد المستخدمة: ' + Object.keys(r.rulesUsed).join('، ');
    setStatus(q('haxeReport'), summary, r.warnings.length > 0);
  };
  q('downloadLua').onclick = function () { if (lastLua) downloadText(lastLua, 'converted.lua', 'text/plain'); };

  // Multi-shader source reader + lightweight character mask paint canvas.
  q('readShader').onclick = function () {
    var list = Array.prototype.slice.call(q('shaderFile').files || []); if (!list.length) return alert('اختر ملف Shader واحداً على الأقل.');
    var rows = [], remaining = list.length, failed = null;
    list.forEach(function(file){ readTextFile(file,function(err,text){ if(err)failed=err; else rows.push({name:file.name,source:text}); remaining--; if(!remaining){
      if(failed)return setStatus(q('shaderOutput'),failed.message,true);
      var profile={target:q('shaderCharacter').value,label:q('shaderLabel').value,opacity:Number(q('shaderOpacity').value),strength:Number(q('shaderStrength').value),noise:Number(q('shaderNoise').value),files:rows.map(function(r){return r.name;})};
      q('shaderOutput').value=rows.map(function(r){return '// ===== '+r.name+' =====\n'+r.source;}).join('\n\n')+'\n\n// PORTYOU_PROFILE\n'+JSON.stringify(profile,null,2);
      if(activeModRoot&&window.Android){for(var si=0;si<rows.length;si++){var shaderFileName=rows[si].name.replace(/[^a-zA-Z0-9_.-]/g,'_');nativeWrite(activeModRoot+'/shaders/'+shaderFileName,rows[si].source);}nativeWrite(activeModRoot+'/data/portyou-shader-profile.json',JSON.stringify(profile,null,2));}
      setStatus(q('shaderMaskInfo'),'تمت قراءة ' + rows.length + ' ملفات Shader. احفظ المصادر مع المود، ثم اربط القناع بShader يقرأه.');
    }}); });
  };
  (function initShaderPainter(){
    var canvas=q('shaderCanvas'),ctx=canvas.getContext('2d'),drawing=false,last=null,erase=false,undo=[],redo=[];
    function snapshot(){try{undo.push(canvas.toDataURL('image/png'));if(undo.length>15)undo.shift();redo=[];}catch(e){}}
    function restore(data,stackFrom,stackTo){if(!data)return;stackFrom.push(canvas.toDataURL('image/png'));var im=new Image();im.onload=function(){ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(im,0,0);};im.src=data;}
    function point(ev){var r=canvas.getBoundingClientRect(),touch=ev.touches&&ev.touches.length?ev.touches[0]:null,cx=touch?touch.clientX:ev.clientX,cy=touch?touch.clientY:ev.clientY;return {x:(cx-r.left)*canvas.width/r.width,y:(cy-r.top)*canvas.height/r.height};}
    function start(ev){if(ev.preventDefault)ev.preventDefault();snapshot();drawing=true;last=point(ev);ctx.beginPath();ctx.moveTo(last.x,last.y);}
    function move(ev){if(!drawing)return;if(ev.preventDefault)ev.preventDefault();var p=point(ev);ctx.save();ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=Number(q('shaderBrushSize').value)||18;ctx.globalAlpha=Number(q('shaderBrushAlpha').value)||0.8;ctx.globalCompositeOperation=erase?'destination-out':'source-over';ctx.strokeStyle=q('shaderBrushColor').value||'#ff42b8';ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();ctx.restore();last=p;}
    function stop(){drawing=false;last=null;}
    canvas.addEventListener('mousedown',start);canvas.addEventListener('mousemove',move);window.addEventListener('mouseup',stop);
    canvas.addEventListener('touchstart',start);canvas.addEventListener('touchmove',move);window.addEventListener('touchend',stop);
    q('shaderEraser').onclick=function(){erase=!erase;this.textContent=erase?'عودة الفرشاة':'ممحاة';};
    q('shaderUndo').onclick=function(){if(!undo.length)return;redo.push(canvas.toDataURL('image/png'));var img=new Image();img.onload=function(){ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0);};img.src=undo.pop();};
    q('shaderRedo').onclick=function(){if(!redo.length)return;undo.push(canvas.toDataURL('image/png'));var img=new Image();img.onload=function(){ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0);};img.src=redo.pop();};
    q('shaderClear').onclick=function(){snapshot();ctx.clearRect(0,0,canvas.width,canvas.height);};
    q('saveShaderMask').onclick=function(){var profile={target:q('shaderCharacter').value,label:q('shaderLabel').value,opacity:Number(q('shaderOpacity').value),strength:Number(q('shaderStrength').value),noise:Number(q('shaderNoise').value),brushColor:q('shaderBrushColor').value,brushSize:Number(q('shaderBrushSize').value),mask:'shader-mask.png',note:'Mask texture only; requires a compatible shader/runtime loader.'};files.shaderMaskResult={png:canvas.toDataURL('image/png'),json:profile};downloadBlob(dataUrlToBlob(files.shaderMaskResult.png),'shader-mask.png');setTimeout(function(){downloadText(JSON.stringify(profile,null,2),'shader-mask-settings.json');},250);if(activeModRoot&&window.Android){writeDataUrl(activeModRoot+'/images/shader-mask.png',files.shaderMaskResult.png);nativeWrite(activeModRoot+'/data/shader-mask-settings.json',JSON.stringify(profile,null,2));}setStatus(q('shaderMaskInfo'),'تم حفظ قناع الرسم وإعداداته. القناع صورة مستقلة ولا يطبق نفسه على الشخصية دون Shader يقرأ texture الخاص به.');};
  }());
  var stageImage = null;
  q('stageImage').onchange = function () {
    var f = this.files[0]; if (!f) return;
    PortYouSprites.imageFromFile(f, function (err, image) { if (!err) { stageImage = image; renderStage(); } else alert(err.message); });
  };
  function renderStage() {
    var canvas = q('stageCanvas'), ctx = canvas.getContext('2d'), x = Number(q('layerX').value) || 0, y = Number(q('layerY').value) || 0, scale = Number(q('layerScale').value) || 1;
    ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = '#e5e5e5'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (stageImage) {
      var w = stageImage.width * scale, h = stageImage.height * scale;
      ctx.drawImage(stageImage, x, y, w, h);
    }
    ctx.fillStyle = '#222'; ctx.font = '12px Arial'; ctx.fillText('Layer: ' + q('layerName').value, 10, 18);
  }
  q('renderStage').onclick = renderStage;

  // Sprite-map/ASTC header inspector.
  q('inspectMap').onclick = function () {
    var meta = q('mapMeta').files[0], image = q('mapImage').files[0];
    if (!meta && !image) return alert('اختر ملف JSON/XML أو صورة ASTC/PNG.');
    var results = [];
    function done() { q('mapReport').textContent = results.join('\n\n'); }
    var pending = (meta ? 1 : 0) + (image ? 1 : 0);
    function complete(s) { results.push(s); pending--; if (!pending) done(); }
    if (meta) readTextFile(meta, function (err, text) {
      if (err) return complete(err.message);
      try {
        var frames = /\.xml$/i.test(meta.name) ? PortYouSprites.parseSparrowXml(text) : PortYouSprites.parseSpritemapJson(parseJson(text, 'Sprite Map JSON'));
        complete('Metadata: ' + meta.name + '\nFrames found: ' + frames.length + '\nSample: ' + JSON.stringify(frames.slice(0, 3), null, 2));
      } catch (ex) { complete(ex.message); }
    });
    if (image) readBuffer(image, function (err, buffer) {
      if (err) return complete(err.message);
      if (/\.astc$/i.test(image.name)) {
        var h = PortYouSprites.readAstcHeader(buffer);
        complete('ASTC: ' + image.name + '\n' + JSON.stringify(h, null, 2) + '\nASTC is compressed texture data. Use the native button to decode standard LDR images to PNG.');
      } else complete('Image: ' + image.name + '\nSize: ' + image.size + ' bytes. PNG preview can be loaded by the Sprite Builder.');
    });
  };


  q('decodeAstcNative').onclick = function () {
    if (!(window.Android && window.Android.pickAstcFile)) {
      setStatus(q('mapReport'), 'فك ASTC الكامل متاح داخل نسخة Android المبنية مع astc-codec. افتح التطبيق من APK بعد تشغيل fetch-native-deps.sh.', true);
      return;
    }
    setStatus(q('mapReport'), 'اختر ملف ASTC قياسياً. سيتم فكّه محلياً وحفظ نسخة PNG داخل مجلد التطبيق…');
    window.Android.pickAstcFile();
  };
  window.onAstcDecoded = function () {
    if (!window.Android) return;
    var err = window.Android.getLastAstcError ? window.Android.getLastAstcError() : '';
    var path = window.Android.getLastAstcOutput ? window.Android.getLastAstcOutput() : '';
    if (err) { setStatus(q('mapReport'), 'فشل فك ASTC: ' + err, true); return; }
    if (!path) { setStatus(q('mapReport'), 'لم ينتج ملف PNG.', true); return; }
    var preview = q('astcDecodedPreview');
    var data = window.Android.readOutputBase64File ? window.Android.readOutputBase64File(path) : '';
    if (data) { preview.src = 'data:image/png;base64,' + data; preview.hidden = false; }
    setStatus(q('mapReport'), 'تم فك الصورة بنجاح إلى PNG.\nالمسار: ' + path + (data ? '\nتظهر المعاينة أعلاه.' : '\nتم حفظ PNG، لكن حجمها أكبر من حد المعاينة داخل الذاكرة.'));
  };


  // Mod archive integration is powered by the native Android bridge. Files are streamed to disk by Java.
  function nativeBridgeAvailable() { return !!(window.Android && window.Android.pickArchive && window.Android.listArchiveFiles); }
  q('pickMod').onclick = function () {
    if (nativeBridgeAvailable()) { window.Android.pickArchive(); return; }
    q('zipFallback').click();
    setStatus(q('archiveInfo'), 'قراءة ZIP وFNMM و7z وRAR وTAR وصيغ 7-Zip الأخرى تتطلب تطبيق Android؛ اختر الأرشيف من داخل APK.');
  };
  q('zipFallback').onchange = function () {
    var f = this.files[0]; if (f) setStatus(q('archiveInfo'), 'اخترت ' + f.name + ' (' + (f.size / 1048576).toFixed(1) + ' MB). فك الأرشيف يتطلب تطبيق Android.');
  };
  window.onNativeArchiveLoaded = function () {
    try {
      currentArchive = JSON.parse(window.Android.listArchiveFiles() || '[]');
      q('convertMod').disabled = false;
      var v = 0, f = 0, i, stages=[], chars=[], images=[];
      for (i = 0; i < currentArchive.length; i++) {
        var path = currentArchive[i].path;
        if (/enterprise-chart\.json$|\-chart\.json$/i.test(path)) v++;
        if (/^data\.json$/i.test(currentArchive[i].name || path.split('/').pop())) f++;
        if (/(^|\/)(stages|data\/stages)\/[^/]+\.json$/i.test(path)) stages.push(path);
        if (/(^|\/)(characters|data\/characters)\/[^/]+\.json$/i.test(path)) chars.push(path);
        if (/\.(png|jpe?g|webp)$/i.test(path) && /(^|\/)images\//i.test(path)) images.push(path);
      }
      function fillSelect(id, values, emptyText) {
        var sel=q(id); while(sel.firstChild)sel.removeChild(sel.firstChild);
        var first=document.createElement('option');first.value='';first.textContent=values.length?'اختر ملفاً':emptyText;sel.appendChild(first);
        for(var k=0;k<values.length;k++){var op=document.createElement('option');op.value=values[k];op.textContent=values[k];sel.appendChild(op);}
      }
      fillSelect('archiveStageSelect',stages,'لا توجد ملفات Stage JSON');
      fillSelect('archiveCharacterSelect',chars,'لا توجد ملفات Character JSON');
      fillSelect('archiveStageAsset',images,'لا توجد صور PNG/JPG');
      var type = v ? 'V-Slice/Polymod' : (f ? 'Funkin Maker' : 'غير معروف');
      setStatus(q('archiveInfo'), 'تم فتح المود. الملفات: ' + currentArchive.length + '\nالكشف الأولي: ' + type + '\nStages: ' + stages.length + ' · Characters: ' + chars.length + ' · Images: ' + images.length + '\nحد الاستيراد 2GB؛ ZIP/FNMM و7z وRAR وTAR وGZip وBZip2 وصيغ 7-Zip الأخرى بحسب الأرشيف.');
      if (q('modType').value === 'auto') q('modType').value = v ? 'vslice' : (f ? 'fnmm' : 'auto');
    } catch (e) { setStatus(q('archiveInfo'), 'تعذر قراءة قائمة ملفات الأرشيف: ' + e.message, true); }
  };
  q('inspectArchiveSelection').onclick = function () {
    var stagePath=q('archiveStageSelect').value, charPath=q('archiveCharacterSelect').value, lines=[];
    if(stagePath){var st=nativeReadJson(stagePath);if(st){lines.push('STAGE: '+stagePath+'\n'+JSON.stringify({directory:st.directory,defaultZoom:st.defaultZoom,isPixelStage:st.isPixelStage,boyfriend:st.boyfriend,dad:st.dad,girlfriend:st.girlfriend,props:st.props||st.objects||st.stageObjects},null,2));
      var refs=JSON.stringify(st);var possible=[];for(var i=0;i<currentArchive.length;i++)if(/\.(frag|vert|glsl)$/i.test(currentArchive[i].path))possible.push(currentArchive[i].path);lines.push('Shader files found: '+(possible.length?possible.join(', '):'none found'));}else lines.push('Could not read selected stage JSON: '+stagePath);}
    else lines.push('No Stage JSON selected.');
    if(charPath){var ch=nativeReadJson(charPath);if(ch){lines.push('CHARACTER: '+charPath+'\n'+JSON.stringify({image:ch.image,healthicon:ch.healthicon,scale:ch.scale,position:ch.position,camera_position:ch.camera_position,flip_x:ch.flip_x,animations:ch.animations},null,2));
      var imageRef=String(ch.image||'').replace(/^images\//,'');var matches=[];for(i=0;i<currentArchive.length;i++)if(imageRef && currentArchive[i].path.indexOf(imageRef)>=0)matches.push(currentArchive[i].path);lines.push('Related image/atlas candidates: '+(matches.length?matches.join(', '):'none matched automatically'));}else lines.push('Could not read selected character JSON: '+charPath);}
    else lines.push('No Character JSON selected.');
    setStatus(q('archiveSelectionReport'),lines.join('\n\n'));
  };
  q('loadArchiveStageAsset').onclick = function () {
    var path=q('archiveStageAsset').value;if(!path)return alert('اختر صورة من القائمة أولاً.');
    var b64=window.Android.readBase64File(path);if(!b64)return setStatus(q('archiveSelectionReport'),'تعذر قراءة الصورة أو تجاوزت حد القراءة 15MB.',true);
    var blob=base64PngToBlob(b64);loadImageFile(blob,function(err,img){if(err)return setStatus(q('archiveSelectionReport'),err.message,true);stageImage=img;renderStage();setStatus(q('archiveSelectionReport'),'تم تحميل '+path+' إلى نافذة المعاينة. أضف الإحداثيات والطبقات يدوياً ثم حدّث المشهد.');});
  };
  function findArchivePath(regex) {
    for (var i = 0; i < currentArchive.length; i++) if (regex.test(currentArchive[i].path)) return currentArchive[i].path;
    return null;
  }
  function findArchivePaths(regex) {
    var out = [];
    for (var i = 0; i < currentArchive.length; i++) if (regex.test(currentArchive[i].path)) out.push(currentArchive[i].path);
    return out;
  }
  function fileBase(path) { return String(path || '').split('/').pop(); }
  function fileDir(path) { var p = String(path || '').split('/'); p.pop(); return p.join('/'); }
  function safeSlug(value) {
    return String(value || 'converted').toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'converted';
  }
  function nativeReadJson(path) {
    if (!path || !window.Android) return null;
    var text = window.Android.readTextFile(path); return text ? parseJson(text, path) : null;
  }
  function nativeWrite(path, text) {
    if (!window.Android || !window.Android.writeTextFile) return false;
    return window.Android.writeTextFile(path, text);
  }
  function nativeCopy(path, target) {
    if (window.Android && window.Android.copyInputFile) return window.Android.copyInputFile(path, target || path);
    return false;
  }
  function writeDataUrl(path, dataUrl) {
    if (!window.Android || !window.Android.writeBase64File || !dataUrl) return false;
    var base64 = String(dataUrl).split(',')[1] || '';
    return window.Android.writeBase64File(path, base64);
  }
  function createWeekArtwork(modRoot, weekId, title) {
    try {
      var c = document.createElement('canvas'), ctx, grad;
      c.width = 1280; c.height = 386; ctx = c.getContext('2d');
      grad = ctx.createLinearGradient(0, 0, 1280, 386);
      grad.addColorStop(0, '#24232b'); grad.addColorStop(0.55, '#5b304d'); grad.addColorStop(1, '#15151a');
      ctx.fillStyle = grad; ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = 'rgba(255,255,255,.10)';
      for (var i = 0; i < 16; i++) { ctx.beginPath(); ctx.arc((i * 97) % 1280, 40 + ((i * 53) % 300), 8 + (i % 5) * 7, 0, Math.PI * 2); ctx.fill(); }
      ctx.fillStyle = '#fff'; ctx.font = 'bold 54px Arial'; ctx.textAlign = 'center'; ctx.fillText(String(title || weekId).slice(0, 28), 640, 210);
      ctx.font = '22px Arial'; ctx.fillStyle = '#f5b6d1'; ctx.fillText('PORTYOU STUDIO · @AxelzeroX23', 640, 270);
      return writeDataUrl(modRoot + '/images/storymenu/weeks/menu_' + weekId + '.png', c.toDataURL('image/png'));
    } catch (e) { return false; }
  }
  function copyVSliceAssets(modRoot, warnings) {
    var i, p, rel, target;
    for (i = 0; i < currentArchive.length; i++) {
      p = currentArchive[i].path;
      if (/\.(png|xml|astc)$/i.test(p) && /(^|\/)images\//i.test(p)) {
        rel = p.replace(/^.*?\/images\//i, '');
        target = modRoot + '/images/' + rel;
        if (!nativeCopy(p, target)) warnings.push('Could not copy image asset: ' + p);
        if (/\.astc$/i.test(p)) warnings.push('ASTC source preserved: ' + p + '. Use the ASTC LDR tool to export a PNG copy before replacing engine references.');
      } else if (/\.(frag|glsl|vert|hxc|hx)$/i.test(p)) {
        rel = fileBase(p);
        nativeCopy(p, modRoot + '/converted-assets/source/' + rel);
      } else if (/\/videos\/.*\.mp4$/i.test(p)) {
        rel = p.replace(/^.*?\/videos\//i, '');
        nativeCopy(p, modRoot + '/videos/' + rel.replace(/^videos\//i, ''));
      }
    }
  }
  function writeVideoEventScripts(modRoot) {
    nativeWrite(modRoot + '/custom_events/PortYou Play Video.lua',
      "-- Generated by PortYou Studio. Requires Psych Engine video support.\n" +
      "function onEvent(name, value1, value2)\n" +
      "  if name == 'PortYou Play Video' and value1 ~= nil and value1 ~= '' then\n" +
      "    startVideo(value1)\n" +
      "  end\nend\n");
    nativeWrite(modRoot + '/custom_events/PortYou Unmapped Event.lua',
      "-- Event payloads are preserved in the chart; implement the event-specific behaviour here.\n" +
      "function onEvent(name, value1, value2)\n" +
      "  if name == 'PortYou Unmapped Event' then\n" +
      "    debugPrint('PortYou preserved event: ' .. tostring(value1) .. ' / ' .. tostring(value2))\n" +
      "  end\nend\n");
  }
  function startOutputBuild(modRoot) {
    if (!window.Android || !window.Android.clearOutput) throw new Error('Android file bridge is unavailable.');
    window.Android.clearOutput();
    if (!window.Android.seedModTemplate || !window.Android.seedModTemplate(modRoot)) {
      throw new Error('تعذر نسخ Psych Engine Mod Template إلى حاوية المود الناتج.');
    }
  }
  function convertVSliceArchive(modRoot, displayName, warnings) {
    var chartPaths = findArchivePaths(/\/data\/songs\/[^/]+\/[^/]+-chart\.json$/i);
    if (!chartPaths.length) throw new Error('لم أجد ملفات data/songs/*/*-chart.json في مود V-Slice.');
    var chartRows = [], songIds = [], i, chartPath, metadataPath, chart, metadata, songId, difficulties, d, converted, songPath, audioPaths;
    for (i = 0; i < chartPaths.length; i++) {
      chartPath = chartPaths[i];
      metadataPath = chartPath.replace(/-chart\.json$/i, '-metadata.json');
      if (!findArchivePath(new RegExp(metadataPath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$'))) {
        metadataPath = findArchivePath(new RegExp('/data/songs/' + fileDir(chartPath).split('/').pop().replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/[^/]+-metadata\\.json$', 'i'));
      }
      chart = nativeReadJson(chartPath); metadata = nativeReadJson(metadataPath);
      if (!chart || !metadata) { warnings.push('Skipped chart without a readable matching metadata file: ' + chartPath); continue; }
      songId = safeSlug(fileBase(chartPath).replace(/-chart\.json$/i, ''));
      songIds.push(songId);
      difficulties = (metadata.playData && metadata.playData.difficulties) || Object.keys(chart.notes || {});
      if (!difficulties || !difficulties.length) difficulties = ['normal'];
      for (d = 0; d < difficulties.length; d++) {
        converted = PortYouConverters.convertVSlice(chart, metadata, { difficulty: difficulties[d], song: songId, flipSides: q('modFlipSides').checked });
        converted.chart.song.song = songId;
        var diffName = safeSlug(difficulties[d]);
        var chartFile = songId + (diffName === 'normal' ? '' : '-' + diffName) + '.json';
        nativeWrite(modRoot + '/data/' + songId + '/' + chartFile, JSON.stringify(converted.chart, null, 2));
        Array.prototype.push.apply(warnings, converted.warnings);
      }
      chartRows.push({ name: songId, icon: safeSlug((metadata.playData && metadata.playData.characters && metadata.playData.characters.opponent) || 'face') });
      audioPaths = findArchivePaths(new RegExp('/songs/' + songId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/[^/]+\\.(ogg|mp3|wav|m4a)$', 'i'));
      for (var a = 0; a < audioPaths.length; a++) {
        var audioName = fileBase(audioPaths[a]);
        var audioTarget = audioName.toLowerCase() === 'inst.ogg' ? 'Inst.ogg' : audioName;
        nativeCopy(audioPaths[a], modRoot + '/songs/' + songId + '/' + audioTarget);
      }
    }
    if (!songIds.length) throw new Error('لم أتمكن من تحويل أي أغنية V-Slice.');

    // Characters: V-Slice metadata maps directly into Psych character JSON, while source atlases remain unchanged.
    var characterPaths = findArchivePaths(/\/data\/characters\/[^/]+\.json$/i);
    for (i = 0; i < characterPaths.length; i++) {
      var characterData = nativeReadJson(characterPaths[i]);
      if (!characterData) { warnings.push('Could not read character: ' + characterPaths[i]); continue; }
      var characterId = safeSlug(fileBase(characterPaths[i]).replace(/\.json$/i, ''));
      var characterOut = PortYouConverters.convertVSliceCharacter(characterData, characterId);
      nativeWrite(modRoot + '/characters/' + characterId + '.json', JSON.stringify(characterOut, null, 2));
      if (characterOut.image) {
        var imagePathFound = false;
        for (var ci = 0; ci < currentArchive.length; ci++) if (currentArchive[ci].path.toLowerCase().indexOf('/' + String(characterOut.image).toLowerCase()) >= 0) imagePathFound = true;
        if (!imagePathFound) warnings.push('Character atlas reference not found by exact assetPath scan: ' + characterOut.image + ' (' + characterId + ')');
      }
    }

    // Stages
    var stagePaths = findArchivePaths(/\/data\/stages\/[^/]+\.json$/i);
    for (i = 0; i < stagePaths.length; i++) {
      var stageData = nativeReadJson(stagePaths[i]); if (!stageData) continue;
      var stageId = safeSlug(fileBase(stagePaths[i]).replace(/\.json$/i, ''));
      var stageOut = PortYouConverters.convertVSliceStage(stageData, stageId);
      nativeWrite(modRoot + '/stages/' + stageId + '.json', JSON.stringify(stageOut, null, 2));
    }
    copyVSliceAssets(modRoot, warnings);
    writeVideoEventScripts(modRoot);

    // Story levels found in the V-Slice mod become Psych week files; otherwise Freeplay-only.
    var levelPaths = findArchivePaths(/\/data\/levels\/[^/]+\.json$/i), generatedStory = 0;
    for (i = 0; i < levelPaths.length; i++) {
      var level = nativeReadJson(levelPaths[i]); if (!level) continue;
      var levelId = safeSlug(fileBase(levelPaths[i]).replace(/\.json$/i, ''));
      var levelSongs = [], srcSongs = level.songs || [], si;
      for (si = 0; si < srcSongs.length; si++) {
        var srcSong = typeof srcSongs[si] === 'string' ? safeSlug(srcSongs[si]) : safeSlug(srcSongs[si].song || srcSongs[si].name);
        if (songIds.indexOf(srcSong) >= 0) levelSongs.push({ name: srcSong, icon: 'face' });
      }
      if (!levelSongs.length) continue;
      var week = PortYouConverters.convertVSliceLevel(level, levelId, levelSongs);
      week.weekBackground = levelId;
      nativeWrite(modRoot + '/weeks/' + levelId + '.json', JSON.stringify(week, null, 2));
      if (!createWeekArtwork(modRoot, levelId, level.name || levelId)) warnings.push('Could not generate story week background for ' + levelId + '.');
      generatedStory++;
    }
    if (!generatedStory) {
      var freeWeek = { songs: chartRows.map(function (r) { return [r.name, r.icon]; }), weekCharacters: ['dad','bf','gf'],
        weekBackground: 'stage', weekBefore: '', storyName: displayName, weekName: displayName,
        startUnlocked: true, hideStoryMode: true, hideFreeplay: false };
      nativeWrite(modRoot + '/weeks/' + safeSlug(displayName) + '.json', JSON.stringify(freeWeek, null, 2));
      warnings.push('No V-Slice data/levels story definition was found; generated Freeplay-only week.');
    }
    return { songs: songIds.length, charts: chartPaths.length, stories: generatedStory };
  }
  function base64PngToBlob(base64) {
    var raw = atob(base64), u8 = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) u8[i] = raw.charCodeAt(i);
    return new Blob([u8], { type: 'image/png' });
  }
  function rebuildFnmmSprites(modRoot, stage, done) {
    var spriteDirs = {}, paths = [], i, m;
    for (i = 0; i < currentArchive.length; i++) {
      m = currentArchive[i].path.match(/(?:^|\/)sprites\/([^/]+)\/([^/]+)$/i);
      if (m) { spriteDirs[m[1]] = true; paths.push(currentArchive[i].path); }
    }
    var names = Object.keys(spriteDirs), roleBySprite = {}, roleList = (stage._portyou && stage._portyou.characterSprites) || [], warnings = [], index = 0;
    for (i = 0; i < roleList.length; i++) roleBySprite[roleList[i].sprite] = roleList[i].role;
    function next() {
      if (index >= names.length) return done(warnings, roleBySprite);
      var folder = names[index++], dirRegex = new RegExp('(?:^|/)sprites/' + folder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/');
      var metaPath = findArchivePath(new RegExp('(?:^|/)sprites/' + folder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/sprite\\.json$', 'i'));
      var imagePaths = findArchivePaths(new RegExp('(?:^|/)sprites/' + folder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/[^/]+\\.png$', 'i'));
      imagePaths.sort(function (a, b) {
        var an = Number(fileBase(a).replace(/\.png$/i, '')), bn = Number(fileBase(b).replace(/\.png$/i, ''));
        return (isNaN(an) ? 0 : an) - (isNaN(bn) ? 0 : bn);
      });
      var spriteMeta = nativeReadJson(metaPath);
      if (!spriteMeta || !imagePaths.length) { warnings.push('Missing sprite.json or PNG strips for ' + folder); return next(); }
      var blobs = [], bIndex = 0;
      function readImage() {
        if (bIndex >= imagePaths.length) {
          var role = roleBySprite[folder] || (/^(player|boyfriend|bf)$/i.test(folder) ? 'boyfriend' : (/^(gf|girlfriend)$/i.test(folder) ? 'girlfriend' : ''));
          var suggested = role === 'boyfriend' ? ['idle','singLEFT','singDOWN','singUP','singRIGHT','extra_5'] : (role === 'girlfriend' ? ['danceLeft','danceRight','idle'] : []);
          PortYouSprites.buildFnmmAtlas(blobs, spriteMeta, { imageName: folder, columns: 4, animationNames: suggested }, function (err, atlas) {
            if (err) { warnings.push('Sprite atlas build failed for ' + folder + ': ' + err.message); return next(); }
            var isCharacter = !!role || Number(spriteMeta.type) === 1;
            var isIcon = Number(spriteMeta.type) === 3;
            var targetFolder = isCharacter ? 'images/characters/' : (isIcon ? 'images/icons/' : 'images/stages/');
            if (!writeDataUrl(modRoot + '/' + targetFolder + folder + '.png', atlas.pngDataUrl)) warnings.push('Atlas PNG could not be written for ' + folder + '.');
            nativeWrite(modRoot + '/' + targetFolder + folder + '.xml', atlas.xml);
            if (isCharacter) {
              var animationRows = atlas.animations.map(function (a) { return { name: a.name, prefix: a.name, fps: a.fps, loop: a.loop, indices: a.indices, x: a.offsetX, y: a.offsetY }; });
              var firstDef = (spriteMeta.data || [])[0] || {};
              var cj = PortYouSprites.buildCharacterJson({ image: 'characters/' + folder, animations: animationRows,
                scale: Number(firstDef.scale) || 1, singDuration: 4, healthIcon: folder, position: [0,0], cameraPosition: [0,0] });
              cj._portyou.source = 'Funkin Maker sprite strips';
              cj._portyou.mappingNeedsReview = true;
              nativeWrite(modRoot + '/characters/' + safeSlug(folder) + '.json', JSON.stringify(cj, null, 2));
              warnings.push('Built character atlas for ' + folder + '; animation names are provisional and must be checked.');
            } else if (isIcon) {
              warnings.push('Icon sprite ' + folder + ' was rebuilt to images/icons but its layout still needs a Psych icon-size review.');
            } else {
              warnings.push('Rebuilt stage/object atlas for ' + folder + '.');
            }
            next();
          });
          return;
        }
        var p = imagePaths[bIndex++], base64 = window.Android.readBase64File(p);
        if (!base64) { warnings.push('PNG strip too large or unreadable (>15MB bridge limit): ' + p); return readImage(); }
        blobs.push(base64PngToBlob(base64)); readImage();
      }
      readImage();
    }
    next();
  }
  function convertFunkinMakerArchive(modRoot, displayName, warnings, finish) {
    var dataPath = findArchivePath(/(?:^|\/)data\.json$/i), eventsPath = findArchivePath(/(?:^|\/)events\.json$/i), scenePath = findArchivePath(/(?:^|\/)scene\.json$/i);
    if (!dataPath || !eventsPath || !scenePath) throw new Error('لم أجد data.json وevents.json وscene.json في أرشيف Funkin Maker.');
    var data = nativeReadJson(dataPath), eventsData = nativeReadJson(eventsPath), scene = nativeReadJson(scenePath);
    if (!data || !eventsData || !scene) throw new Error('تعذر قراءة أحد ملفات data/events/scene JSON.');
    var stage = PortYouConverters.buildFunkinMakerStage(scene, {}), roles = stage._portyou.characterSprites || [];
    var player = 'bf', opponent = 'dad', girlfriend = 'gf';
    for (var i = 0; i < roles.length; i++) {
      if (roles[i].role === 'boyfriend') player = roles[i].sprite;
      if (roles[i].role === 'opponent') opponent = roles[i].sprite;
      if (roles[i].role === 'girlfriend') girlfriend = roles[i].sprite;
    }
    var slug = safeSlug(displayName);
    var converted = PortYouConverters.convertFunkinMaker(data, eventsData, scene, { flipSides: q('modFlipSides').checked, player1: player, player2: opponent, gfVersion: girlfriend, song: slug });
    converted.chart.song.song = slug;
    nativeWrite(modRoot + '/data/' + slug + '/' + slug + '.json', JSON.stringify(converted.chart, null, 2));
    nativeWrite(modRoot + '/stages/' + slug + '_stage.json', JSON.stringify(converted.stage, null, 2));
    nativeWrite(modRoot + '/weeks/' + slug + '.json', JSON.stringify({ songs: [[slug, 'face']], weekCharacters: ['dad','bf','gf'], weekBackground: slug + '_stage', weekBefore: '', storyName: displayName, weekName: displayName, startUnlocked: true, hideStoryMode: true, hideFreeplay: false }, null, 2));
    if (converted.warnings) Array.prototype.push.apply(warnings, converted.warnings);
    var musicPath = findArchivePath(/(?:^|\/)music\.ogg$/i);
    if (musicPath) nativeCopy(musicPath, modRoot + '/songs/' + slug + '/Inst.ogg');
    var icons = (scene.icons || []);
    for (i = 0; i < icons.length; i++) {
      var iconFolder = String(icons[i]);
      var iconImages = findArchivePaths(new RegExp('(?:^|/)sprites/' + iconFolder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/[^/]+\\.png$', 'i'));
      for (var ii = 0; ii < iconImages.length; ii++) nativeCopy(iconImages[ii], modRoot + '/converted-assets/fnmm-icons/' + iconFolder + '/' + fileBase(iconImages[ii]));
    }
    rebuildFnmmSprites(modRoot, converted.stage, function (spriteWarnings) {
      Array.prototype.push.apply(warnings, spriteWarnings || []);
      nativeWrite(modRoot + '/custom_events/FNMM Object Sprite.lua',
        "-- PortYou preserved this event and its arguments. Map stage-object tags to your scene before enabling.\n" +
        "function onEvent(name, value1, value2)\n" +
        "  if name == 'FNMM Object Sprite' then\n" +
        "    debugPrint('FNMM sprite change needs scene-object binding: ' .. tostring(value1) .. ' -> ' .. tostring(value2))\n" +
        "  end\nend\n");
      nativeWrite(modRoot + '/custom_events/FNMM Object Strumline.lua',
        "-- PortYou preserved ObjectChartChange timing and values. A runtime strumline remapper is required.\n" +
        "function onEvent(name, value1, value2)\n" +
        "  if name == 'FNMM Object Strumline' then\n" +
        "    debugPrint('FNMM strumline remap requires runtime mapping: ' .. tostring(value1) .. ' -> ' .. tostring(value2))\n" +
        "  end\nend\n");
      createWeekArtwork(modRoot, slug + '_stage', displayName);
      finish({ sprites: Object.keys((function(){var o={};for(var j=0;j<currentArchive.length;j++){var mm=currentArchive[j].path.match(/(?:^|\/)sprites\/([^/]+)\//);if(mm)o[mm[1]]=1;}return o;}())).length });
    });
  }
  q('convertMod').onclick = function () {
    if (!nativeBridgeAvailable() || !currentArchive.length) return setStatus(q('modReport'), 'افتح المود من خلال تطبيق Android أولاً.', true);
    var type = q('modType').value, name = q('modName').value || 'ConvertedMod', safeName = String(name).replace(/[^A-Za-z0-9_-]/g, '_'), modRoot = 'mods/' + safeName, warnings = [];
    activeModRoot = modRoot; q('exportMod').disabled = true;
    try {
      if (type === 'auto') type = findArchivePath(/\/data\/songs\/[^/]+\/[^/]+-chart\.json$/i) ? 'vslice' : 'fnmm';
      startOutputBuild(modRoot);
      nativeWrite(modRoot + '/pack.json', JSON.stringify({ name: safeName, description: 'Offline converted by PortYou Studio · @AxelzeroX23', restart: false, runsGlobally: false, color: [237,119,172] }, null, 2));
      if (type === 'vslice') {
        var vResult = convertVSliceArchive(modRoot, safeName, warnings);
        nativeWrite(modRoot + '/data/portyou-report.json', JSON.stringify({ source: 'V-Slice / Polymod', songs: vResult.songs, chartFiles: vResult.charts, storyWeeks: vResult.stories, warnings: warnings,
          limitations: ['ASTC originals are preserved; use the standalone ASTC LDR decoder to create PNG copies. HDR is unsupported.', 'Unknown V-Slice events are preserved in custom-event rows but need event-specific Lua implementations.', 'Haxe/HXC scripts are retained as source; arbitrary Haxe is not safely transpiled into equivalent Lua.'] }, null, 2));
        q('exportMod').disabled = false;
        setStatus(q('modReport'), 'اكتمل بناء مسودة V-Slice إلى Psych.\nالأغاني/الشارتات: ' + vResult.songs + '\nملفات الشارت: ' + vResult.charts + '\nStory weeks: ' + vResult.stories + '\n\n' + (warnings.length ? warnings.join('\n') : 'لم تُرصد مشكلات تحويل في البيانات المقروءة.') + '\n\nمهم: الأصول ASTC محفوظة كما هي لكنها تحتاج فكاً حقيقياً إلى PNG قبل أن يعرضها Psych Engine.');
      } else {
        convertFunkinMakerArchive(modRoot, safeName, warnings, function (result) {
          nativeWrite(modRoot + '/data/portyou-report.json', JSON.stringify({ source: 'Funkin Maker', spritesRebuilt: result.sprites, warnings: warnings,
            limitations: ['Animation naming is provisional because the sample sprite.json stores frame counts/speed/offsets but no named animation labels.', 'FNMM Object Sprite and Object Strumline timings are preserved; runtime mapping still needs implementation for full scene fidelity.', 'Custom story mode assets are absent in the supplied FNMM sample, so a Freeplay-only week was generated.'] }, null, 2));
          q('exportMod').disabled = false;
          setStatus(q('modReport'), 'اكتمل بناء مسودة Funkin Maker إلى Psych.\nتم تحويل أوقات النوتات من الثواني إلى المللي ثانية مع الفصل بين اللاعب والخصم.\nتمت إعادة بناء أطالس PNG/XML للشخصيات والكائنات التي أمكن قراءتها.\n\n' + (warnings.length ? warnings.join('\n') : 'لم تُرصد أخطاء بنيوية.') + '\n\nراجع أسماء الحركات وصور الأيقونات وأحداث تبديل الكائن/المسار قبل تشغيل المود.');
        });
      }
    } catch (ex) { setStatus(q('modReport'), ex.message, true); }
  };
  q('exportMod').onclick = function () {
    if (window.Android && window.Android.createOutputZip) {
      var result = window.Android.createOutputZip();
      setStatus(q('modReport'), result || 'تم تجهيز ZIP في مجلد التنزيلات الخاص بالتطبيق.');
    }
  };

  // Partial UI localization for Saudi Arabic and Brazilian Portuguese.
  var labels = {
    ar:{home:'الرئيسية',settings:'الإعدادات',tools:'الأدوات'},
    sy:{home:'الصفحة الرئيسية',settings:'الضبط',tools:'الأدوات'},
    fr:{home:'Accueil',settings:'Paramètres',tools:'Outils'},
    th:{home:'หน้าแรก',settings:'ตั้งค่า',tools:'เครื่องมือ'},
    ja:{home:'ホーム',settings:'設定',tools:'ツール'},
    'ar-SA':{home:'الرئيسية',settings:'الإعدادات',tools:'الأدوات'},
    'pt-BR':{home:'Início',settings:'Configurações',tools:'Ferramentas'}
  };
  var uiText = {
    'ar-SA': {
      homeStageButton:'تعديل الستاج', homeVsliceButton:'تحويل V-Slice إلى Psych', homeMakerButton:'تحويل Funkin’ Maker', homeFriendsButton:'الروابط والأصدقاء',
      stageTitle:'محرر المود والستاج', vsliceTitle:'تحويل V-Slice إلى Psych Engine 1.0.4', makerTitle:'تحويل Funkin’ Maker إلى Psych', toolsTitle:'الأدوات',
      toolCharacter:'صانع الشخصيات والسبرايت', toolNotes:'محرر الأسهم', toolAudio:'تحويل ودمج الصوت', toolScripts:'تحويل Haxe إلى Lua', toolShaders:'إدارة Shaders', toolAstc:'قارئ ASTC وSprite Map',
      characterTitle:'صانع الشخصيات والسبرايت', notesTitle:'محرر الأسهم وHold', audioTitle:'تحويل ودمج الصوت دون إنترنت', scriptsTitle:'محوّل Haxe وHScript إلى Lua', shadersTitle:'إدارة Shaders', astcTitle:'قارئ Sprite Map وASTC',
      settingsTitle:'الإعدادات والروابط', friendsTitle:'AxelzeroX23 والأصدقاء', convertMod:'تحليل وبناء مجلد Psych Engine', exportMod:'تصدير المود بصيغة ZIP', convertVslice:'تحويل الشارت', flipPsychChart:'عكس أسهم اللاعب والخصم', convertFnmm:'تحويل الشارت والستاج',
      buildBta:'دمج Spritemap إلى Sprite عادي', readAtlas:'قراءة وتقسيم الفريمات', buildFnmmSprite:'إنشاء أطلس وXML وCharacter JSON', mixAudio:'تحويل ودمج إلى OGG', convertHaxe:'تحويل الكود إلى Lua', readShader:'قراءة ملفات Shader', inspectMap:'قراءة بيانات Sprite Map وASTC', decodeAstcNative:'فك ASTC إلى PNG',
      developerYoutubeLink:'قناة المطوّر على YouTube', languagePanelTitle:'اللغات', settingsSubBack:'العودة إلى الإعدادات', socialTitle:'روابط المطوّر', socialDescription:'افتح رابط قناة المطوّر الرسمية.', settingsMainDescription:'المس الرموز لفتح اللغات والصوت ومعلومات التطبيق. استخدم الروابط لزيارة القنوات.', languagePanelDescription:'اختر لغة الواجهة. بعض التفاصيل ورسائل التحويل ما زالت بالعربية.', languageSelectLabel:'لغة الواجهة', soundPanelTitle:'إعدادات الصوت', musicOnLabel:'موسيقى التطبيق', tapOnLabel:'أصوات اللمس', aboutTitle:'حول PortYou Studio'
    },
    'pt-BR': {
      homeStageButton:'Editar estágio', homeVsliceButton:'Converter V-Slice para Psych', homeMakerButton:'Converter Funkin’ Maker', homeFriendsButton:'Links e amigos',
      stageTitle:'Editor de mod e estágio', vsliceTitle:'V-Slice para Psych Engine 1.0.4', makerTitle:'Funkin’ Maker para Psych', toolsTitle:'Ferramentas',
      toolCharacter:'Criador de personagens e sprites', toolNotes:'Editor de notas', toolAudio:'Converter e mixar áudio', toolScripts:'Converter Haxe para Lua', toolShaders:'Gerenciar shaders', toolAstc:'Leitor ASTC e Sprite Map',
      characterTitle:'Criador de personagens e sprites', notesTitle:'Editor de notas e Holds', audioTitle:'Conversor e mixer de áudio offline', scriptsTitle:'Conversor Haxe/HScript para Lua', shadersTitle:'Gerenciador de shaders', astcTitle:'Leitor de Sprite Map e ASTC',
      settingsTitle:'Configurações e links', friendsTitle:'AxelzeroX23 e amigos', convertMod:'Analisar e criar pasta Psych Engine', exportMod:'Exportar mod como ZIP', convertVslice:'Converter chart', flipPsychChart:'Inverter lados das notas', convertFnmm:'Converter chart e estágio',
      buildBta:'Montar Spritemap como sprite comum', readAtlas:'Ler e separar frames', buildFnmmSprite:'Criar atlas, XML e Character JSON', mixAudio:'Converter e mixar para OGG', convertHaxe:'Converter código para Lua', readShader:'Ler arquivos Shader', inspectMap:'Ler dados do Sprite Map e ASTC', decodeAstcNative:'Decodificar ASTC para PNG',
      developerYoutubeLink:'Canal do desenvolvedor no YouTube', languagePanelTitle:'Idiomas', settingsSubBack:'Voltar às configurações', socialTitle:'Links do desenvolvedor', socialDescription:'Abra o canal oficial do desenvolvedor.', settingsMainDescription:'Toque nos ícones para abrir idiomas, áudio e informações. Use os links para visitar os canais.', languagePanelDescription:'Escolha o idioma da interface. Alguns detalhes e mensagens de conversão ainda estão em árabe.', languageSelectLabel:'Idioma da interface', soundPanelTitle:'Configurações de áudio', musicOnLabel:'Música do aplicativo', tapOnLabel:'Sons de toque', aboutTitle:'Sobre o PortYou Studio'
    }
  };
  function applyLanguage(lang) {
    var label = labels[lang] || labels.ar, dict = uiText[lang] || {};
    q('settingsBtn').title = label.settings;
    q('backBtn').title = label.home;
    q('toolsScreen').setAttribute('data-current-language', lang);
    document.documentElement.lang = lang;
    document.body.dir = lang === 'pt-BR' ? 'ltr' : 'rtl';
    Object.keys(dict).forEach(function (id) { if (q(id)) q(id).textContent = dict[id]; });
    if (!q('aboutArtwork').hidden) q('aboutDescription').textContent = aboutText[lang] || aboutText.ar;
    if (q('languagePanelTitle')) q('languagePanelTitle').textContent = dict.languagePanelTitle || 'Language / اللغات';
    if (q('developerYoutubeLink')) q('developerYoutubeLink').textContent = dict.developerYoutubeLink || 'YouTube — AxelzeroX23 ↗';
  }
  q('language').onchange = function () { applyLanguage(this.value); };
  q('settingsSubBack').onclick = function () { randomSettingsArt(); showSettingsView('main', false); };
  applyLanguage(q('language').value || 'ar');

  // Android 5+ WebView host supplies the native file chooser for HTML file inputs.
  if (!window.FileReader || !window.HTMLCanvasElement) {
    setStatus(q('archiveInfo'), 'متصفح WebView هذا لا يدعم قراءة الملفات أو Canvas المطلوبة. حدّث Android System WebView ثم أعد فتح التطبيق.');
  }
  window.addEventListener('load', function () { renderStage(); });
}());
