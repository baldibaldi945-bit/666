/* Offline MP3/WAV -> OGG Vorbis converter and simultaneous mixer.
 * The OggVorbisEncoder vendor bundle is loaded locally by index.html.
 */
(function (root) {
  'use strict';
  function getAudioContext() { var C = root.AudioContext || root.webkitAudioContext; return C ? new C() : null; }
  function extension(file) {
    var name = String(file && file.name || '').toLowerCase();
    var dot = name.lastIndexOf('.');
    return dot < 0 ? '' : name.substring(dot + 1);
  }
  function isSupportedInput(file) {
    var ext = extension(file);
    return ext === 'mp3' || ext === 'wav';
  }
  function decodeFile(ctx, file, done) {
    var reader = new FileReader(), settled = false;
    function finish(err, buffer) {
      if (settled) return;
      settled = true;
      done(err || null, buffer || null);
    }
    reader.onload = function (e) {
      var data = e.target.result;
      var onSuccess = function (buffer) { finish(null, buffer); };
      var onFailure = function (err) { finish(err || new Error('Audio decode failed')); };
      try {
        var result = ctx.decodeAudioData(data, onSuccess, onFailure);
        if (result && typeof result.then === 'function') result.then(onSuccess, onFailure);
      } catch (err) { onFailure(err); }
    };
    reader.onerror = function () { finish(new Error('Audio file could not be read.')); };
    reader.readAsArrayBuffer(file);
  }
  function mixFiles(files, options, callback) {
    options = options || {}; files = files || [];
    if (!files.length) return callback(new Error('Choose one or more MP3/WAV files.'));
    var bad = [], i;
    for (i = 0; i < files.length; i++) if (!isSupportedInput(files[i])) bad.push(files[i].name || 'unknown');
    if (bad.length) return callback(new Error('Only MP3 and WAV are accepted. Unsupported: ' + bad.join(', ')));
    if (!root.OggVorbisEncoder) return callback(new Error('Local OGG encoder is missing. Run scripts/fetch-codecs.sh and rebuild the app.'));
    var ctx = getAudioContext();
    if (!ctx) return callback(new Error('This Android WebView does not provide Web Audio decoding. Try a newer WebView.'));
    var buffers = [], complete = 0, firstError = null;
    for (i = 0; i < files.length; i++) (function (idx) {
      decodeFile(ctx, files[idx], function (err, buf) {
        if (err && !firstError) firstError = err;
        buffers[idx] = buf || null; complete++;
        if (complete === files.length) {
          if (firstError) { if (ctx.close) ctx.close(); return callback(firstError); }
          try {
            var rate = Number(options.sampleRate) || buffers[0].sampleRate;
            var maxLen = 0, channels = 1, j, b;
            for (j = 0; j < buffers.length; j++) {
              b = buffers[j];
              maxLen = Math.max(maxLen, Math.ceil(b.duration * rate));
              channels = Math.max(channels, Math.min(2, b.numberOfChannels));
            }
            if (maxLen > rate * 600) throw new Error('Audio mix exceeds the 10 minute safety limit for this legacy Android target.');
            var out = [], ch, src, pos, targetIndex, peak = 0;
            for (ch = 0; ch < channels; ch++) out[ch] = new Float32Array(maxLen);
            // Every source begins at time zero. They are summed, not concatenated.
            for (j = 0; j < buffers.length; j++) {
              b = buffers[j];
              for (ch = 0; ch < channels; ch++) {
                src = b.getChannelData(Math.min(ch, b.numberOfChannels - 1));
                for (pos = 0; pos < src.length; pos++) {
                  targetIndex = Math.floor(pos * rate / b.sampleRate);
                  if (targetIndex < maxLen) out[ch][targetIndex] += src[pos];
                }
              }
            }
            for (ch = 0; ch < channels; ch++) for (pos = 0; pos < out[ch].length; pos++) peak = Math.max(peak, Math.abs(out[ch][pos]));
            var gain = peak > 0.98 ? 0.98 / peak : 1;
            if (gain !== 1) for (ch = 0; ch < channels; ch++) for (pos = 0; pos < out[ch].length; pos++) out[ch][pos] *= gain;

            var encoder = new root.OggVorbisEncoder(rate, channels, Number(options.quality) || 0.5);
            var chunkSize = 8192, start, end, chunk, c;
            for (start = 0; start < maxLen; start += chunkSize) {
              end = Math.min(maxLen, start + chunkSize); chunk = [];
              for (c = 0; c < channels; c++) chunk.push(out[c].subarray(start, end));
              encoder.encode(chunk);
            }
            var oggBlob = encoder.finish('audio/ogg');
            callback(null, { ogg: oggBlob, duration: maxLen / rate, sampleRate: rate,
              channels: channels, trackCount: buffers.length, normalizerGain: gain, format: 'ogg' });
          } catch (ex) { callback(ex); }
          if (ctx.close) ctx.close();
        }
      });
    }(i));
  }
  root.PortYouAudio = { mixFiles: mixFiles, isSupportedInput: isSupportedInput, inputFormats: ['mp3', 'wav'], outputFormat: 'ogg' };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PortYouAudio;
}(this));
