/*
 * PortYou Haxe/HScript -> Psych Engine Lua translator.
 * This is a conservative, source-preserving transpiler for common gameplay
 * scripting patterns. Unknown Haxe constructs become TODO comments rather
 * than being silently deleted or emitted as fake Lua.
 */
(function (root) {
  'use strict';

  var CALLBACKS = {
    onCreate: true, onCreatePost: true, onUpdate: true, onUpdatePost: true,
    onBeatHit: true, onStepHit: true, onSongStart: true, onSongEnd: true,
    onEvent: true, goodNoteHit: true, opponentNoteHit: true, noteMiss: true,
    noteMissPress: true, onSpawnNote: true, onTweenCompleted: true, onTimerCompleted: true, onMoveCamera: true, onGameOver: true,
    onGameOverStart: true, onGameOverConfirm: true, onPause: true, onResume: true, onDestroy: true,
    onSectionHit: true, onKeyPressPre: true, onKeyReleasePre: true, onKeyPress: true, onKeyRelease: true,
    onGhostTap: true, goodNoteHitPre: true, opponentNoteHitPre: true, eventEarlyTrigger: true,
    onRecalculateRating: true, onNextDialogue: true, onSkipDialogue: true, onStartCountdown: true, onEndSong: true
  };

  function trimSemicolon(s) { return s.replace(/;\s*$/, '').trim(); }
  function splitArguments(text) {
    var out = [], start = 0, depth = 0, quote = '', escaped = false, i, c;
    for (i = 0; i < text.length; i++) {
      c = text.charAt(i);
      if (quote) {
        if (escaped) escaped = false;
        else if (c === '\\') escaped = true;
        else if (c === quote) quote = '';
      } else if (c === '"' || c === "'") quote = c;
      else if (c === '(' || c === '[' || c === '{' || c === '<') depth++;
      else if (c === ')' || c === ']' || c === '}' || c === '>') depth = Math.max(0, depth - 1);
      else if (c === ',' && depth === 0) { out.push(text.slice(start, i).trim()); start = i + 1; }
    }
    if (text.slice(start).trim()) out.push(text.slice(start).trim());
    return out;
  }

  function convertParameters(text) {
    return splitArguments(text).map(function (arg) {
      // Haxe: ?value:Float = 1  -> Lua: value
      arg = arg.replace(/^\?/, '').trim();
      var eq = arg.indexOf('=');
      var left = eq >= 0 ? arg.slice(0, eq).trim() : arg;
      var right = eq >= 0 ? arg.slice(eq + 1).trim() : '';
      left = left.replace(/:\s*[A-Za-z0-9_.$<>?]+(?:\s*\[\])?$/, '').trim();
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(left)) return null;
      return left + (right ? ' -- Haxe default was: ' + right : '');
    }).filter(Boolean).map(function (s) { return s.replace(/\s+-- Haxe default was:.*/, ''); }).join(', ');
  }

  function convertExpression(expr) {
    var s = String(expr || '').trim();
    // Haxe constants and operators; strings remain unchanged.
    s = s.replace(/\bnull\b/g, 'nil');
    s = s.replace(/&&/g, ' and ').replace(/\|\|/g, ' or ');
    s = s.replace(/(^|[^=!<>])!(?!=)/g, '$1not ');
    s = s.replace(/\bMath\.PI\b/g, 'math.pi');
    s = s.replace(/\bMath\.(abs|floor|ceil|sqrt|sin|cos|tan|exp|log|min|max|pow)\b/g, 'math.$1');
    s = s.replace(/\bStd\.int\(([^()]*)\)/g, 'math.floor($1)');
    s = s.replace(/\bStd\.string\(([^()]*)\)/g, 'tostring($1)');
    s = s.replace(/\bStd\.parseInt\(([^()]*)\)/g, 'tonumber($1)');
    s = s.replace(/\bStd\.parseFloat\(([^()]*)\)/g, 'tonumber($1)');
    s = s.replace(/\bPaths\.(?:image|sound|music)\((['"])([^'"]+)\1\)/g, function (_, q, name) { return q + name + q; });
    s = s.replace(/\bFlxG\.keys\.justPressed\.([A-Za-z0-9_]+)/g, function (_, key) { return "keyboardJustPressed('" + key.toLowerCase() + "')"; });
    s = s.replace(/\bFlxG\.keys\.justReleased\.([A-Za-z0-9_]+)/g, function (_, key) { return "keyboardReleased('" + key.toLowerCase() + "')"; });
    s = s.replace(/\bFlxG\.keys\.pressed\.([A-Za-z0-9_]+)/g, function (_, key) { return "keyboardPressed('" + key.toLowerCase() + "')"; });
    return s;
  }

  function mapStatement(line) {
    var s = trimSemicolon(line), m, value;
    if (!s) return { code: '', mapped: true };

    // Calls and engine helpers with stable Psych Lua equivalents.
    m = s.match(/^trace\((.*)\)$/);
    if (m) return { code: 'debugPrint(' + convertExpression(m[1]) + ')', mapped: true, rule: 'trace -> debugPrint' };
    m = s.match(/^(?:PlayState\.instance\.|game\.)?(dad|boyfriend|gf|girlfriend)\.playAnim\((.*)\)$/);
    if (m) return { code: "characterPlayAnim('" + (m[1] === 'girlfriend' ? 'gf' : m[1]) + "', " + convertExpression(m[2]) + ')', mapped: true, rule: 'character animation' };
    m = s.match(/^(?:PlayState\.instance\.|game\.)?(dad|boyfriend|gf|girlfriend)\.dance\(\)$/);
    if (m) return { code: "characterDance('" + (m[1] === 'girlfriend' ? 'gf' : m[1]) + "')", mapped: true, rule: 'character dance' };

    // Camera values. Psych names cameras as game / hud / other.
    m = s.match(/^(?:FlxG\.camera|game\.camGame|PlayState\.instance\.camGame)\.(zoom|alpha|angle)\s*=\s*(.+)$/);
    if (m) return { code: "setProperty('camGame." + m[1] + "', " + convertExpression(m[2]) + ')', mapped: true, rule: 'game camera property' };
    m = s.match(/^(?:game\.camHUD|PlayState\.instance\.camHUD)\.(zoom|alpha|angle)\s*=\s*(.+)$/);
    if (m) return { code: "setProperty('camHUD." + m[1] + "', " + convertExpression(m[2]) + ')', mapped: true, rule: 'HUD camera property' };
    m = s.match(/^(?:FlxG\.camera|game\.camGame|PlayState\.instance\.camGame)\.(zoom|alpha|angle)\s*([+\-])=\s*(.+)$/);
    if (m) return { code: "setProperty('camGame." + m[1] + "', getProperty('camGame." + m[1] + "') " + m[2] + ' ' + convertExpression(m[3]) + ')', mapped: true, rule: 'game camera compound property' };
    m = s.match(/^(?:FlxG\.camera|game\.camGame|PlayState\.instance\.camGame)\.shake\((.*)\)$/);
    if (m) return { code: "cameraShake('game', " + convertExpression(m[1]) + ')', mapped: true, rule: 'game camera shake' };
    m = s.match(/^(?:game\.camHUD|PlayState\.instance\.camHUD)\.shake\((.*)\)$/);
    if (m) return { code: "cameraShake('hud', " + convertExpression(m[1]) + ')', mapped: true, rule: 'HUD camera shake' };
    m = s.match(/^(?:FlxG\.camera|game\.camGame|PlayState\.instance\.camGame)\.flash\((.*)\)$/);
    if (m) return { code: "cameraFlash('game', " + convertExpression(m[1]) + ')', mapped: true, rule: 'game camera flash' };
    m = s.match(/^(?:game\.camHUD|PlayState\.instance\.camHUD)\.flash\((.*)\)$/);
    if (m) return { code: "cameraFlash('hud', " + convertExpression(m[1]) + ')', mapped: true, rule: 'HUD camera flash' };
    m = s.match(/^(?:FlxG\.camera|game\.camGame|PlayState\.instance\.camGame)\.fade\((.*)\)$/);
    if (m) return { code: "cameraFade('game', " + convertExpression(m[1]) + ')', mapped: true, rule: 'game camera fade' };

    // Common sprite/character/camera operations frequently found in Haxe mod scripts.
    m = s.match(/^(?:game\.|PlayState\.instance\.)?(dad|boyfriend|gf|girlfriend)\.setPosition\((.*)\)$/);
    if (m) {
      var role = m[1] === 'girlfriend' ? 'gf' : m[1], xy = splitArguments(m[2]);
      if (xy.length >= 2) return { code: "setProperty('" + role + ".x', " + convertExpression(xy[0]) + "); setProperty('" + role + ".y', " + convertExpression(xy[1]) + ')', mapped: true, rule: 'character set position' };
    }
    m = s.match(/^(?:game\.|PlayState\.instance\.)?(dad|boyfriend|gf|girlfriend)\.setGraphicSize\((.*)\)$/);
    if (m) {
      var roleSize = m[1] === 'girlfriend' ? 'gf' : m[1], sizeArgs = splitArguments(m[2]);
      // FlxSprite.setGraphicSize takes pixel dimensions; Psych's Lua helper
      // with the same name preserves those semantics. scaleObject is a ratio.
      if (sizeArgs.length) return { code: "setGraphicSize('" + roleSize + "', " + convertExpression(sizeArgs[0]) + ', ' + convertExpression(sizeArgs[1] || '0') + ')', mapped: true, rule: 'character graphic size in pixels' };
    }
    m = s.match(/^(?:game\.|PlayState\.instance\.)?(dad|boyfriend|gf|girlfriend)\.visible\s*=\s*(.+)$/);
    if (m) return { code: "setProperty('" + (m[1] === 'girlfriend' ? 'gf' : m[1]) + ".visible', " + convertExpression(m[2]) + ')', mapped: true, rule: 'character visibility' };
    m = s.match(/^(?:FlxG\.camera|game\.camGame|PlayState\.instance\.camGame)\.scroll\.(x|y)\s*=\s*(.+)$/);
    if (m) return { code: "setProperty('camFollow." + m[1] + "', " + convertExpression(m[2]) + ')', mapped: true, rule: 'camera follow position' };

    // Map simple FlxTween.tween property objects to Psych's doTween helpers.
    m = s.match(/^FlxTween\.tween\(([^,]+),\s*\{([^}]+)\},\s*([^,]+)(?:,\s*\{(.*)\})?\)$/);
    if (m) {
      var target = m[1].trim().replace(/^(?:game\.|PlayState\.instance\.)/, '');
      if (target === 'FlxG.camera') target = 'camGame';
      if (/^(dad|boyfriend|gf|camGame|camHUD|camFollow)$/.test(target)) {
        var opts = m[4] || '';
        if (/\bonComplete\b|\bonUpdate\b/.test(opts)) return { code: '-- TODO_PORTYOU: FlxTween callback requires manual Lua conversion: ' + s, mapped: false, reason: 'FlxTween callback closures are not translated automatically.' };
        var easeMatch = opts.match(/\bease\s*:\s*FlxEase\.([A-Za-z0-9_]+)/), easeName = easeMatch ? easeMatch[1] : 'linear';
        var props = splitArguments(m[2]), tweenLines = [];
        for (var pi = 0; pi < props.length; pi++) {
          var pair = props[pi].match(/^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.+)$/);
          if (!pair) return { code: '-- TODO_PORTYOU: unsupported FlxTween property: ' + s, mapped: false, reason: 'Complex FlxTween property object needs manual review.' };
          var prop = pair[1], suffix = prop.charAt(0).toUpperCase() + prop.slice(1);
          if (!/^(x|y|alpha|angle|zoom)$/.test(prop)) return { code: '-- TODO_PORTYOU: FlxTween property ' + prop + ' is not mapped.', mapped: false, reason: 'No verified Psych doTween equivalent for this property.' };
          var tag = 'portyou_' + target.replace(/[^A-Za-z0-9_]/g, '_') + '_' + prop;
          tweenLines.push('doTween' + suffix + "('" + tag + "', '" + target + "', " + convertExpression(pair[2]) + ', ' + convertExpression(m[3]) + ", '" + easeName + "')");
        }
        if (tweenLines.length) return { code: tweenLines.join('\n'), mapped: true, rule: 'simple FlxTween to Psych doTween' };
      }
    }

    // Game state values and camera-follow values.
    m = s.match(/^(?:PlayState\.instance\.)?game\.health\s*=\s*(.+)$/) || s.match(/^PlayState\.instance\.health\s*=\s*(.+)$/) || s.match(/^game\.health\s*=\s*(.+)$/);
    if (m) return { code: "setProperty('health', " + convertExpression(m[1]) + ')', mapped: true, rule: 'health value' };
    m = s.match(/^(?:game\.|PlayState\.instance\.)?health\s*([+\-])=\s*(.+)$/);
    if (m) return { code: "setProperty('health', getProperty('health') " + m[1] + ' ' + convertExpression(m[2]) + ')', mapped: true, rule: 'health increment' };
    m = s.match(/^(?:game\.|PlayState\.instance\.)?(dad|boyfriend|gf|camFollow)\.(x|y|alpha|angle|visible|flipX)\s*=\s*(.+)$/);
    if (m) return { code: "setProperty('" + m[1] + '.' + m[2] + "', " + convertExpression(m[3]) + ')', mapped: true, rule: 'common object property' };
    m = s.match(/^(?:game\.|PlayState\.instance\.)?currentCameraZoom\s*=\s*(.+)$/);
    if (m) return { code: "setProperty('defaultCamZoom', " + convertExpression(m[1]) + ')', mapped: true, rule: 'default camera zoom' };

    // Sound calls. Paths.sound/music have already been simplified by expression conversion.
    m = s.match(/^FlxG\.sound\.play\((.*)\)$/);
    if (m) return { code: 'playSound(' + convertExpression(m[1]) + ')', mapped: true, rule: 'sound play' };
    m = s.match(/^FlxG\.sound\.playMusic\((.*)\)$/);
    if (m) return { code: 'playMusic(' + convertExpression(m[1]) + ')', mapped: true, rule: 'music play' };
    if (/^(?:FlxG\.sound\.)?music\.stop\(\)$/.test(s) || /^FlxG\.sound\.music\.stop\(\)$/.test(s)) return { code: "stopSound('')", mapped: true, rule: 'music stop' };
    if (/^FlxG\.sound\.music\.pause\(\)$/.test(s)) return { code: "pauseSound('')", mapped: true, rule: 'music pause' };
    if (/^FlxG\.sound\.music\.resume\(\)$/.test(s)) return { code: "resumeSound('')", mapped: true, rule: 'music resume' };
    m = s.match(/^FlxG\.sound\.music\.fadeOut\((.*)\)$/);
    if (m) return { code: "soundFadeOut('', " + convertExpression(m[1]) + ', 0)', mapped: true, rule: 'music fade out' };
    m = s.match(/^FlxG\.sound\.music\.volume\s*=\s*(.+)$/);
    if (m) return { code: "setPropertyFromClass('flixel.FlxG', 'sound.music.volume', " + convertExpression(m[1]) + ')', mapped: true, rule: 'music volume' };

    // Input / random / events / countdown.
    m = s.match(/^Countdown\.skipCountdown\(\)$/) || s.match(/^game\.startCountdown\(\)$/);
    if (m) return { code: 'startCountdown()', mapped: true, rule: 'start countdown' };
    m = s.match(/^(?:game\.|PlayState\.instance\.)?triggerEvent\((.*)\)$/);
    if (m) return { code: 'triggerEvent(' + convertExpression(m[1]) + ')', mapped: true, rule: 'trigger event' };
    m = s.match(/^FlxG\.random\.int\((.*)\)$/);
    if (m) return { code: 'getRandomInt(' + convertExpression(m[1]) + ')', mapped: true, rule: 'random integer' };
    m = s.match(/^FlxG\.random\.float\((.*)\)$/);
    if (m) return { code: 'getRandomFloat(' + convertExpression(m[1]) + ')', mapped: true, rule: 'random float' };
    m = s.match(/^FlxG\.mouse\.visible\s*=\s*(.+)$/);
    if (m) return { code: "setPropertyFromClass('flixel.FlxG', 'mouse.visible', " + convertExpression(m[1]) + ')', mapped: true, rule: 'mouse visibility' };

    // Primitive declarations and assignments are safe to simplify.
    m = s.match(/^(?:var|final)\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(Int|Float|Bool|String|Dynamic)\s*=\s*(.+)$/);
    if (m) return { code: 'local ' + m[1] + ' = ' + convertExpression(m[3]), mapped: true, rule: 'typed primitive variable' };
    m = s.match(/^(?:var|final)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$/);
    if (m) return { code: 'local ' + m[1] + ' = ' + convertExpression(m[2]), mapped: true, rule: 'local variable' };
    m = s.match(/^([A-Za-z_][A-Za-z0-9_.]*)\s*([+\-])=\s*(.+)$/);
    if (m) return { code: m[1] + ' = ' + m[1] + ' ' + m[2] + ' ' + convertExpression(m[3]), mapped: true, rule: 'compound assignment' };
    m = s.match(/^([A-Za-z_][A-Za-z0-9_.]*)\s*(\+\+|--)$/);
    if (m) return { code: m[1] + ' = ' + m[1] + (m[2] === '++' ? ' + 1' : ' - 1'), mapped: true, rule: 'increment/decrement' };

    if (/^return(?:\s+.*)?$/.test(s)) return { code: convertExpression(s), mapped: true, rule: 'return' };
    if (/^(?:break|continue)$/.test(s)) return { code: s === 'continue' ? '-- TODO_PORTYOU: Haxe continue semantics need a Lua loop rewrite.' : 'break', mapped: s !== 'continue', rule: 'loop control' };

    // Conservative fallback: ordinary Lua-like calls and assignments can pass through after expression rewrites.
    if (/^[A-Za-z_][A-Za-z0-9_.]*\s*\(.*\)$/.test(s) || /^[A-Za-z_][A-Za-z0-9_.]*\s*=/.test(s)) {
      value = convertExpression(s);
      if (!/\b(?:Flx|PlayState|Paths|CoolUtil|Conductor|Std|Type|Reflect|Assets|openfl|haxe)\w*/.test(value)) return { code: value, mapped: true, rule: 'Lua-compatible statement' };
    }
    return { code: '-- TODO_PORTYOU: ' + line, mapped: false, reason: 'No verified Psych Lua mapping for this Haxe construct.' };
  }

  function convert(code) {
    var lines = String(code || '').replace(/\r\n?/g, '\n').split('\n');
    var output = ['-- PortYou Haxe/HScript -> Psych Engine Lua', '-- Generated conservatively: review TODO_PORTYOU and test in Psych Engine 1.0.4 Mobile.'];
    var warnings = [], rulesUsed = {}, stack = [], inBlockComment = false, mappedCount = 0, i, raw, line, t, m, item, indent;

    function push(text) { var prefix = new Array(stack.filter(function (b) { return b.emitEnd; }).length + 1).join('    '); output.push(prefix + String(text).replace(/\n/g, '\n' + prefix)); }
    function closeTop() {
      if (!stack.length) { warnings.push('Unmatched closing brace near source line ' + (i + 1)); return; }
      var b = stack.pop();
      if (b.emitEnd) output.push(new Array(stack.filter(function (x) { return x.emitEnd; }).length + 1).join('    ') + 'end');
    }
    function braceDelta(sourceLine) {
      var quote = '', escaped = false, delta = 0;
      for (var bi = 0; bi < sourceLine.length; bi++) {
        var ch = sourceLine.charAt(bi);
        if (quote) {
          if (escaped) escaped = false;
          else if (ch === String.fromCharCode(92)) escaped = true;
          else if (ch === quote) quote = '';
        } else if (ch === '"' || ch === "'") quote = ch;
        else if (ch === '{') delta++;
        else if (ch === '}') delta--;
      }
      return delta;
    }
    function markTodo(sourceLine, why) {
      push('-- TODO_PORTYOU [' + (i + 1) + ']: ' + sourceLine.trim());
      warnings.push('Line ' + (i + 1) + ': ' + (why || 'manual rewrite required') + ' — ' + sourceLine.trim().slice(0, 110));
    }

    for (i = 0; i < lines.length; i++) {
      raw = lines[i]; line = raw; t = line.trim();
      if (!t) { output.push(''); continue; }
      if (stack.length && stack[stack.length - 1].opaque) {
        push('-- TODO_PORTYOU [opaque Haxe block]: ' + t);
        stack[stack.length - 1].depth += braceDelta(raw);
        if (stack[stack.length - 1].depth <= 0) stack.pop();
        continue;
      }
      if (inBlockComment) {
        output.push('-- ' + t.replace(/^\*\s?/, ''));
        if (t.indexOf('*/') >= 0) inBlockComment = false;
        continue;
      }
      if (/^\/\*/.test(t)) {
        output.push('-- ' + t.replace(/^\/\*\s?/, ''));
        if (t.indexOf('*/') < 0) inBlockComment = true;
        continue;
      }
      if (/^\/\//.test(t) || /^\*/.test(t)) { push('-- ' + t.replace(/^\/\//, '').replace(/^\*/, '')); continue; }
      if (/^(package|import|using)\s/.test(t)) { push('-- ' + t); continue; }

      // Preserve class/enum declarations as comments; their method bodies are lifted to Lua functions.
      m = t.match(/^(?:public\s+|private\s+|extern\s+|abstract\s+)?(?:class|interface|enum|typedef)\s+([A-Za-z0-9_]+).*\{\s*$/);
      if (m) { push('-- ' + t.replace(/\s*\{\s*$/, ' (type scope)')); stack.push({kind: 'type', emitEnd: false}); continue; }

      // Closing brace paired with an else branch. Keep the original if block open in Lua.
      m = t.match(/^\}\s*else\s+if\s*\((.*)\)\s*\{\s*$/);
      if (m) {
        if (!stack.length || stack[stack.length - 1].kind !== 'if') { markTodo(raw, 'else-if block is not paired with a recognized if block'); continue; }
        push('elseif ' + convertExpression(m[1]) + ' then');
        continue;
      }
      if (/^\}\s*else\s*\{\s*$/.test(t)) {
        if (!stack.length || stack[stack.length - 1].kind !== 'if') { markTodo(raw, 'else block is not paired with a recognized if block'); continue; }
        push('else'); continue;
      }
      if (/^\}\s*$/.test(t)) {
        var nextIndex = i + 1, nextLine = '';
        while (nextIndex < lines.length && !lines[nextIndex].trim()) nextIndex++;
        if (nextIndex < lines.length) nextLine = lines[nextIndex].trim();
        if (stack.length && stack[stack.length - 1].kind === 'if' && (/^else\s+if\b/.test(nextLine) || /^else\s*\{/.test(nextLine))) continue;
        closeTop(); continue;
      }

      // Callback or ordinary method declaration; retain every argument name.
      m = t.match(/^(?:(?:public|private|override|static|inline|final|extern)\s+)*function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*(?::\s*[A-Za-z0-9_.$<>?]+)?\s*\{\s*$/);
      if (m) {
        var args = convertParameters(m[2]);
        push('function ' + m[1] + '(' + args + ')');
        stack.push({kind: 'function', emitEnd: true});
        continue;
      }

      // Supported control-flow blocks.
      m = t.match(/^if\s*\((.*)\)\s*\{\s*$/);
      if (m) { push('if ' + convertExpression(m[1]) + ' then'); stack.push({kind: 'if', emitEnd: true}); continue; }
      m = t.match(/^else\s+if\s*\((.*)\)\s*\{\s*$/);
      if (m) {
        if (stack.length && stack[stack.length - 1].kind === 'if') push('elseif ' + convertExpression(m[1]) + ' then');
        else { markTodo(raw, 'detached else-if was retained as a review block to avoid invalid Lua'); stack.push({kind: 'opaque', emitEnd: false, opaque: true, depth: braceDelta(raw)}); }
        continue;
      }
      if (/^else\s*\{\s*$/.test(t)) {
        if (stack.length && stack[stack.length - 1].kind === 'if') push('else');
        else { markTodo(raw, 'detached else block was retained as a review block'); stack.push({kind: 'opaque', emitEnd: false, opaque: true, depth: braceDelta(raw)}); }
        continue;
      }
      m = t.match(/^while\s*\((.*)\)\s*\{\s*$/);
      if (m) { push('while ' + convertExpression(m[1]) + ' do'); stack.push({kind: 'loop', emitEnd: true}); continue; }
      m = t.match(/^for\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s+in\s+(\d+)\.\.\.([^)]+)\)\s*\{\s*$/);
      if (m) { push('for ' + m[1] + ' = ' + m[2] + ', (' + convertExpression(m[3]) + ') - 1 do'); stack.push({kind: 'loop', emitEnd: true}); continue; }
      m = t.match(/^for\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s+in\s+([A-Za-z_][A-Za-z0-9_.]*)\s*\)\s*\{\s*$/);
      if (m) { push('for _, ' + m[1] + ' in ipairs(' + m[2] + ') do'); stack.push({kind: 'loop', emitEnd: true}); continue; }

      if (/^(?:switch\b|try\s*\{|catch\s*\()/.test(t)) {
        markTodo(raw, 'switch/try/catch requires structural rewriting; the whole block is retained as TODO comments');
        var opaqueDepth = braceDelta(raw);
        if (opaqueDepth > 0) stack.push({kind: 'opaque', emitEnd: false, opaque: true, depth: opaqueDepth});
        continue;
      }
      if (/^\}$/.test(t)) { closeTop(); continue; }

      // One-line control flow is handled only when the whole statement is simple.
      m = t.match(/^if\s*\((.*)\)\s+(.+);?$/);
      if (m && m[2].indexOf('{') < 0) {
        item = mapStatement(m[2]);
        if (item.mapped) { push('if ' + convertExpression(m[1]) + ' then ' + item.code + ' end'); mappedCount++; }
        else markTodo(raw, 'one-line if contains unsupported statement');
        continue;
      }

      item = mapStatement(raw);
      if (item.mapped) {
        if (item.code) push(item.code);
        mappedCount++;
        if (item.rule) rulesUsed[item.rule] = (rulesUsed[item.rule] || 0) + 1;
      } else markTodo(raw, item.reason);
    }

    while (stack.length) {
      var open = stack.pop();
      if (open.emitEnd) output.push('end -- TODO_PORTYOU: auto-closed an unmatched Haxe block');
      warnings.push('Unclosed ' + open.kind + ' block at end of input.');
    }
    if (inBlockComment) warnings.push('Unterminated Haxe block comment.');
    output.push('', '-- Conversion summary: ' + mappedCount + ' mapped source statements; ' + warnings.length + ' review item(s).');
    output.push('-- Required review: Haxe class state, Flixel object lifecycle, tweens/timers, shaders, custom note logic, and engine internals.');
    return { lua: output.join('\n') + '\n', warnings: warnings, mappedCount: mappedCount, rulesUsed: rulesUsed, sourceLines: lines.length };
  }

  var api = { translate: convert, convertExpression: convertExpression, convertParameters: convertParameters };
  root.PortYouHaxe = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
}(this));
