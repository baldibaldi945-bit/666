/* Sprite atlas utilities. Browser APIs used here are optional; all source images stay unchanged. */
(function (root) {
  'use strict';
  function arr(v) { return Object.prototype.toString.call(v) === '[object Array]' ? v : []; }
  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function num(v, d) { var n = Number(v); return isFinite(n) ? n : d; }
  function cleanName(s) { return String(s || 'frame').replace(/[\\/:*?"<>|]/g, '_'); }
  function pad4(v) { var s = String(v); while (s.length < 4) s = '0' + s; return s; }

  function readAstcHeader(buffer) {
    var b = new Uint8Array(buffer);
    if (b.length < 16 || b[0] !== 0x13 || b[1] !== 0xAB || b[2] !== 0xA1 || b[3] !== 0x5C) {
      return { valid: false, message: 'Not an ASTC file (magic header mismatch).' };
    }
    function u24(i) { return b[i] | (b[i + 1] << 8) | (b[i + 2] << 16); }
    return { valid: true, blockX: b[4], blockY: b[5], blockZ: b[6],
      width: u24(7), height: u24(10), depth: u24(13),
      bytes: b.length, needsDecoder: true };
  }

  function parseSparrowXml(xmlText) {
    var out = [], re = /<SubTexture\b([^>]*?)\/?\s*>/gi, m, attrs, a, kv, values;
    while ((m = re.exec(xmlText || '')) !== null) {
      attrs = {}; a = /([A-Za-z0-9_]+)\s*=\s*(["'])(.*?)\2/g;
      while ((kv = a.exec(m[1])) !== null) attrs[kv[1]] = kv[3];
      values = { name: cleanName(attrs.name || ('frame' + out.length)),
        x: num(attrs.x, 0), y: num(attrs.y, 0), width: num(attrs.width, 0), height: num(attrs.height, 0),
        frameWidth: num(attrs.frameWidth, num(attrs.width, 0)), frameHeight: num(attrs.frameHeight, num(attrs.height, 0)),
        frameX: num(attrs.frameX, 0), frameY: num(attrs.frameY, 0) };
      if (values.width > 0 && values.height > 0) out.push(values);
    }
    return out;
  }

  function parseSpritemapJson(data) {
    data = obj(data);
    if (data.ATLAS && arr(data.ATLAS.SPRITES).length) {
      var btaFrames = [], source, sprite;
      for (var bi = 0; bi < data.ATLAS.SPRITES.length; bi++) {
        source = obj(data.ATLAS.SPRITES[bi]); sprite = obj(source.SPRITE);
        if (sprite.w > 0 && sprite.h > 0) btaFrames.push({ name: cleanName(sprite.name || ('sprite' + bi)), x: num(sprite.x, 0), y: num(sprite.y, 0), width: num(sprite.w, 0), height: num(sprite.h, 0), rotated: !!sprite.rotated });
      }
      return btaFrames;
    }
    var frames = data.frames || data.atlas || data.textures || data.sprites || [];
    var out = [], key, item, rect;
    if (Object.prototype.toString.call(frames) === '[object Array]') {
      for (var i = 0; i < frames.length; i++) {
        item = obj(frames[i]); rect = obj(item.frame || item.rect || item);
        if (rect.w !== undefined || rect.width !== undefined) out.push({
          name: cleanName(item.filename || item.name || ('frame' + i)),
          x: num(rect.x, 0), y: num(rect.y, 0), width: num(rect.w !== undefined ? rect.w : rect.width, 0),
          height: num(rect.h !== undefined ? rect.h : rect.height, 0),
          frameWidth: num(obj(item.sourceSize).w, num(rect.w, num(rect.width, 0))),
          frameHeight: num(obj(item.sourceSize).h, num(rect.h, num(rect.height, 0))),
          frameX: num(obj(item.spriteSourceSize).x, 0), frameY: num(obj(item.spriteSourceSize).y, 0),
          rotated: !!item.rotated
        });
      }
    } else {
      for (key in frames) if (Object.prototype.hasOwnProperty.call(frames, key)) {
        item = obj(frames[key]); rect = obj(item.frame || item.rect || item);
        if (rect.w !== undefined || rect.width !== undefined) out.push({
          name: cleanName(item.filename || key), x: num(rect.x, 0), y: num(rect.y, 0),
          width: num(rect.w !== undefined ? rect.w : rect.width, 0),
          height: num(rect.h !== undefined ? rect.h : rect.height, 0),
          frameWidth: num(obj(item.sourceSize).w, num(rect.w, num(rect.width, 0))),
          frameHeight: num(obj(item.sourceSize).h, num(rect.h, num(rect.height, 0))),
          frameX: num(obj(item.spriteSourceSize).x, 0), frameY: num(obj(item.spriteSourceSize).y, 0),
          rotated: !!item.rotated
        });
      }
    }
    return out;
  }

  function imageFromFile(file, callback) {
    if (!root.FileReader || !root.Image) return callback(new Error('Image preview requires a modern browser canvas API.'));
    var reader = new FileReader();
    reader.onload = function (ev) { var im = new Image(); im.onload = function () { callback(null, im); }; im.onerror = function () { callback(new Error('Image decode failed.')); }; im.src = ev.target.result; };
    reader.onerror = function () { callback(new Error('File read failed.')); };
    reader.readAsDataURL(file);
  }

  function cutFrames(image, frames, options, callback) {
    options = obj(options); frames = arr(frames);
    if (!root.document || !root.document.createElement) return callback(new Error('Canvas is not available.'));
    var maxW = 1, maxH = 1, i;
    for (i = 0; i < frames.length; i++) { maxW = Math.max(maxW, frames[i].frameWidth || frames[i].width); maxH = Math.max(maxH, frames[i].frameHeight || frames[i].height); }
    var columns = Math.max(1, Math.floor(num(options.columns, Math.ceil(Math.sqrt(frames.length || 1)))));
    var rows = Math.ceil(frames.length / columns), gap = Math.max(0, num(options.gap, 0));
    var canvas = document.createElement('canvas'); canvas.width = columns * (maxW + gap); canvas.height = rows * (maxH + gap);
    var ctx = canvas.getContext('2d'), xml = ['<?xml version="1.0" encoding="utf-8"?>', '<TextureAtlas imagePath="' + cleanName(options.imageName || 'atlas') + '">'];
    for (i = 0; i < frames.length; i++) {
      var f = frames[i], col = i % columns, row = Math.floor(i / columns), dx = col * (maxW + gap), dy = row * (maxH + gap);
      if (f.rotated) { callback(new Error('Rotated atlas frames need a manual correction before export: ' + f.name)); return; }
      ctx.drawImage(image, f.x, f.y, f.width, f.height, dx + (f.frameX || 0), dy + (f.frameY || 0), f.width, f.height);
      xml.push('<SubTexture name="' + f.name + '" x="' + dx + '" y="' + dy + '" width="' + f.width + '" height="' + f.height + '" frameWidth="' + (f.frameWidth || f.width) + '" frameHeight="' + (f.frameHeight || f.height) + '" frameX="' + (f.frameX || 0) + '" frameY="' + (f.frameY || 0) + '"/>');
    }
    xml.push('</TextureAtlas>');
    callback(null, { pngDataUrl: canvas.toDataURL('image/png'), xml: xml.join('\n'), width: canvas.width, height: canvas.height, frameCount: frames.length });
  }

  function buildFnmmAtlas(images, spriteJson, options, callback) {
    images = arr(images); spriteJson = obj(spriteJson); options = obj(options);
    var defs = arr(spriteJson.data), frames = [], suggested = ['idle', 'singLEFT', 'singDOWN', 'singUP', 'singRIGHT'];
    if (!root.document || !root.document.createElement) return callback(new Error('Canvas is not available.'));
    var loaded = 0, sourceImages = [], error = null, callbackDone = false;
    function finishCallback(err, result) { if (callbackDone) return; callbackDone = true; callback(err, result); }
    if (!defs.length || !images.length) return finishCallback(new Error('Missing sprites or sprite.json data.'));
    function finishLoad() {
      if (loaded !== images.length) return;
      if (error) return finishCallback(error);
      var frameW = [], frameH = [], animNames = arr(options.animationNames), flat = [], i, j, d, im, count, w, h;
      for (i = 0; i < images.length; i++) {
        d = defs[i] || {}; im = sourceImages[i]; count = Math.max(1, Math.floor(num(d.num, 1)));
        if (!im || im.width % count !== 0) { error = new Error('Sprite ' + i + ' width is not divisible by its declared frame count (' + count + ').'); return finishCallback(error); }
        w = im.width / count; h = im.height;
        for (j = 0; j < count; j++) flat.push({ image: im, sx: j * w, sy: 0, sw: w, sh: h,
          name: cleanName((animNames[i] || suggested[i] || ('extra_' + i)) + pad4(j)),
          animation: animNames[i] || suggested[i] || ('extra_' + i), fps: num(d.spd, 24), loop: d.loop !== false,
          offsetX: num(obj(d.offset).x, 0), offsetY: num(obj(d.offset).y, 0), sourceIndex: i });
      }
      var maxW = 1, maxH = 1, animCounters = {};
      for (i = 0; i < flat.length; i++) { maxW = Math.max(maxW, flat[i].sw); maxH = Math.max(maxH, flat[i].sh); }
      var columns = Math.max(1, Math.floor(num(options.columns, 4))), rows = Math.ceil(flat.length / columns);
      var canvas = document.createElement('canvas'); canvas.width = columns * maxW; canvas.height = rows * maxH;
      var maxSide = Math.max(256, Math.floor(num(options.maxCanvasSide, 4096)));
      if (canvas.width > maxSide || canvas.height > maxSide) return finishCallback(new Error('Generated sprite atlas exceeds mobile canvas limit (' + maxSide + 'px per side).'));
      var ctx = canvas.getContext('2d'), xml = ['<?xml version="1.0" encoding="utf-8"?>', '<TextureAtlas imagePath="' + cleanName(options.imageName || 'character') + '">'], anims = [], pos;
      for (i = 0; i < flat.length; i++) {
        pos = { x: (i % columns) * maxW, y: Math.floor(i / columns) * maxH };
        ctx.drawImage(flat[i].image, flat[i].sx, flat[i].sy, flat[i].sw, flat[i].sh, pos.x, pos.y, flat[i].sw, flat[i].sh);
        var animFrame = animCounters[flat[i].animation] || 0;
        var nm = flat[i].animation + pad4(animFrame);
        animCounters[flat[i].animation] = animFrame + 1;
        xml.push('<SubTexture name="' + nm + '" x="' + pos.x + '" y="' + pos.y + '" width="' + flat[i].sw + '" height="' + flat[i].sh + '" frameWidth="' + flat[i].sw + '" frameHeight="' + flat[i].sh + '" frameX="0" frameY="0"/>');
        var found = false;
        for (j = 0; j < anims.length; j++) if (anims[j].name === flat[i].animation) { anims[j].indices.push(i); found = true; break; }
        if (!found) anims.push({ name: flat[i].animation, indices: [i], fps: flat[i].fps, loop: flat[i].loop, offsetX: flat[i].offsetX, offsetY: flat[i].offsetY });
      }
      xml.push('</TextureAtlas>');
      finishCallback(null, { pngDataUrl: canvas.toDataURL('image/png'), xml: xml.join('\n'), animations: anims, frameCount: flat.length, width: canvas.width, height: canvas.height, mappingNeedsReview: true,
        warnings: defs.length !== images.length ? ['sprite.json contains ' + defs.length + ' animation rows but ' + images.length + ' PNG strips were supplied.'] : [] });
    }
    for (var i = 0; i < images.length; i++) (function (index) {
      imageFromFile(images[index], function (err, img) { if (err) error = err; else sourceImages[index] = img; loaded++; finishLoad(); });
    }(i));
  }

  function matrixFor(el) {
    el = obj(el);
    if (arr(el.MX).length >= 6) return el.MX.slice(0, 6).map(function (v) { return num(v, 0); });
    if (arr(el.M3D).length >= 16) { var m = el.M3D; return [num(m[0],1), num(m[1],0), num(m[4],0), num(m[5],1), num(m[12],0), num(m[13],0)]; }
    return [1,0,0,1,0,0];
  }
  function matrixMultiply(a, b) {
    return [a[0]*b[0]+a[2]*b[1], a[1]*b[0]+a[3]*b[1], a[0]*b[2]+a[2]*b[3], a[1]*b[2]+a[3]*b[3], a[0]*b[4]+a[2]*b[5]+a[4], a[1]*b[4]+a[3]*b[5]+a[5]];
  }
  function matrixPoint(m, x, y) { return [m[0]*x+m[2]*y+m[4], m[1]*x+m[3]*y+m[5]]; }
  function btaSymbolLength(symbol) {
    var max = 0, layers = arr(obj(obj(symbol).TL).L);
    for (var i = 0; i < layers.length; i++) for (var j = 0; j < arr(layers[i].FR).length; j++) {
      var fr = layers[i].FR[j]; max = Math.max(max, num(fr.I,0) + num(fr.DU,1));
    }
    return max || 1;
  }
  function btaFrameBlock(layer, frame) {
    var list = arr(obj(layer).FR);
    for (var i = 0; i < list.length; i++) {
      var f = list[i], start = num(f.I,0), duration = num(f.DU,1);
      if (frame >= start && frame < start + duration) return f;
    }
    return null;
  }
  function btaAlpha(si) {
    var c = obj(obj(si).C), mode = String(c.M || '');
    if (mode === 'CA' || mode === 'Alpha' || mode === 'AD' || mode === 'Advanced') return Math.max(0, Math.min(1, num(c.AM,1)));
    return 1;
  }
  function btaAnimations(animation) {
    var out = [], layers = arr(obj(obj(animation.AN).TL).L), seen = {}, i, j, fr;
    for (i = 0; i < layers.length; i++) for (j = 0; j < arr(layers[i].FR).length; j++) {
      fr = layers[i].FR[j];
      if (fr.N && fr.N !== 'None' && !seen[fr.N]) {
        seen[fr.N] = true; out.push({ name: cleanName(fr.N), type: 'label', start: num(fr.I,0), duration: num(fr.DU,1) });
      }
    }
    if (out.length) { out.sort(function(a,b){return a.start-b.start;}); return out; }
    var symbols = arr(obj(animation.SD).S), rootRefs = {}, subRefs = {}, layer, frame, el, symbol, name, len;
    for (i = 0; i < layers.length; i++) for (j = 0; j < arr(layers[i].FR).length; j++) {
      frame = layers[i].FR[j]; for (var k = 0; k < arr(frame.E).length; k++) { el = frame.E[k]; if (el.SI && el.SI.SN) rootRefs[el.SI.SN] = true; }
    }
    for (i = 0; i < symbols.length; i++) {
      symbol = symbols[i]; for (j = 0; j < arr(obj(symbol.TL).L).length; j++) {
        layer = symbol.TL.L[j]; for (var f = 0; f < arr(layer.FR).length; f++) for (var e = 0; e < arr(layer.FR[f].E).length; e++) {
          el = layer.FR[f].E[e]; if (el.SI && el.SI.SN && !rootRefs[el.SI.SN]) subRefs[el.SI.SN] = true;
        }
      }
    }
    for (i = 0; i < symbols.length; i++) {
      symbol = symbols[i]; name = String(symbol.SN || '');
      if (!name || subRefs[name] || /^z_parts\//i.test(name) || /\/parts\//i.test(name) || /\bparts\b/i.test(name) || /^symbol\s+\d+$/i.test(name)) continue;
      len = btaSymbolLength(symbol); if (len > 0) out.push({ name: cleanName(name), type: 'symbol', symbol: symbol, start: 0, duration: len });
    }
    return out;
  }
  function renderBtaToSparrow(image, spritemapData, animationData, options, callback) {
    options = obj(options); spritemapData = obj(spritemapData); animationData = obj(animationData);
    if (!root.document || !root.document.createElement) return callback(new Error('Canvas API is not available.'));
    if (!spritemapData.ATLAS || !arr(spritemapData.ATLAS.SPRITES).length || !animationData.AN || !animationData.AN.TL) return callback(new Error('Invalid Adobe Animate Spritemap/Animation JSON.'));
    var spriteMap = {}, symbols = {}, entries = arr(spritemapData.ATLAS.SPRITES), symbolRows = arr(obj(animationData.SD).S), animations = btaAnimations(animationData), i, sprite;
    for (i = 0; i < entries.length; i++) { sprite = obj(entries[i].SPRITE); if (sprite.name) spriteMap[sprite.name] = sprite; }
    for (i = 0; i < symbolRows.length; i++) if (symbolRows[i].SN) symbols[symbolRows[i].SN] = symbolRows[i];
    if (!animations.length) return callback(new Error('No named timeline or playable symbol was found in Animation JSON.'));
    var globalBounds = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity }, maxDepth = 24;
    function visitTimeline(tl, frame, matrix, alpha, onSprite, depth) {
      if (!tl || !arr(tl.L).length || depth > maxDepth) return;
      for (var li = tl.L.length - 1; li >= 0; li--) {
        var layer = tl.L[li], block = btaFrameBlock(layer, frame); if (!block) continue;
        var localFrame = frame - num(block.I,0), elements = arr(block.E);
        for (var ei = 0; ei < elements.length; ei++) {
          var el = elements[ei];
          if (el.ASI) {
            var asi = obj(el.ASI), sp = spriteMap[asi.N]; if (!sp) continue;
            var mm = matrixMultiply(matrix, matrixFor(asi));
            onSprite(sp, mm, alpha);
          } else if (el.SI) {
            var si = obj(el.SI), sym = symbols[si.SN]; if (!sym) continue;
            var len = btaSymbolLength(sym), ff = num(si.FF,0), lp = String(si.LP || 'LP'), cf;
            if (lp === 'SF' || lp === 'singleframe') cf = ff;
            else if (lp === 'PO' || lp === 'playonce') cf = Math.min(ff + localFrame, len - 1);
            else cf = ((ff + localFrame) % len + len) % len;
            visitTimeline(sym.TL, cf, matrixMultiply(matrix, matrixFor(si)), alpha * btaAlpha(si), onSprite, depth + 1);
          }
        }
      }
    }
    function rootTransform(useRoot) {
      var rootSI = obj(obj(obj(animationData.AN).STI).SI);
      return useRoot && rootSI ? matrixFor(rootSI) : [1,0,0,1,0,0];
    }
    function collectBounds(anim, frame) {
      var useRoot = anim.type !== 'symbol', m = rootTransform(useRoot);
      visitTimeline(anim.type === 'symbol' ? anim.symbol.TL : animationData.AN.TL, anim.type === 'symbol' ? frame : frame, m, 1, function(sp, matrix) {
        var w = num(sp.w,0), h = num(sp.h,0), dw = sp.rotated ? h : w, dh = sp.rotated ? w : h;
        var pts = [matrixPoint(matrix,0,0), matrixPoint(matrix,dw,0), matrixPoint(matrix,0,dh), matrixPoint(matrix,dw,dh)];
        for (var k = 0; k < pts.length; k++) { globalBounds.minX = Math.min(globalBounds.minX,pts[k][0]); globalBounds.maxX = Math.max(globalBounds.maxX,pts[k][0]); globalBounds.minY = Math.min(globalBounds.minY,pts[k][1]); globalBounds.maxY = Math.max(globalBounds.maxY,pts[k][1]); }
      }, 0);
    }
    var totalFrames = 0, frameRecords = [], ai, f, anim, dur;
    for (ai = 0; ai < animations.length; ai++) {
      anim = animations[ai]; dur = Math.min(1000, Math.max(1, Math.floor(num(anim.duration,1))));
      anim.frameOffset = frameRecords.length;
      for (f = 0; f < dur; f++) {
        var frameNumber = num(anim.start,0) + f;
        frameRecords.push({ animation: anim.name, animationIndex: ai, localFrame: f, frame: frameNumber, type: anim.type, symbol: anim.symbol });
        collectBounds(anim, frameNumber);
      }
      totalFrames += dur;
    }
    if (globalBounds.minX === Infinity) return callback(new Error('The animation contains no drawable bitmap sprite instances.'));
    var pad = Math.max(0, num(options.padding, 2)), frameW = Math.ceil(globalBounds.maxX - globalBounds.minX) + pad * 2, frameH = Math.ceil(globalBounds.maxY - globalBounds.minY) + pad * 2;
    var columns = Math.max(1, Math.floor(num(options.columns, 4))), rows = Math.ceil(frameRecords.length / columns);
    var maxSide = Math.max(256, Math.floor(num(options.maxCanvasSide, 4096)));
    if (frameW * columns > maxSide || frameH * rows > maxSide) return callback(new Error('Generated atlas exceeds the mobile canvas safety size. Reduce columns or export fewer animation ranges.'));
    var canvas = document.createElement('canvas'); canvas.width = columns * frameW; canvas.height = rows * frameH;
    var ctx = canvas.getContext('2d'), xml = ['<?xml version="1.0" encoding="utf-8"?>', '<TextureAtlas imagePath="' + cleanName(options.imageName || 'bta_atlas') + '">'], animationOut = [], counters = {};
    for (ai = 0; ai < animations.length; ai++) animationOut.push({ name: animations[ai].name, indices: [], fps: num(obj(animationData.MD).FRT,24), loop: true, offsetX: 0, offsetY: 0 });
    function drawSprite(sp, matrix, alpha) {
      var m = matrix, w = num(sp.w,0), h = num(sp.h,0);
      ctx.save(); ctx.transform(m[0],m[1],m[2],m[3],m[4],m[5]); ctx.globalAlpha *= alpha;
      if (sp.rotated) { ctx.translate(0,w); ctx.rotate(-Math.PI/2); }
      ctx.drawImage(image, num(sp.x,0), num(sp.y,0), w, h, 0, 0, w, h); ctx.restore();
    }
    for (i = 0; i < frameRecords.length; i++) {
      var rec = frameRecords[i], col = i % columns, row = Math.floor(i / columns), dx = col * frameW, dy = row * frameH;
      ctx.save(); ctx.translate(dx + pad - globalBounds.minX, dy + pad - globalBounds.minY);
      var rootM = rootTransform(rec.type !== 'symbol');
      visitTimeline(rec.type === 'symbol' ? rec.symbol.TL : animationData.AN.TL, rec.frame, rootM, 1, drawSprite, 0);
      ctx.restore();
      var ix = animationOut[rec.animationIndex].indices.length;
      var frameName = rec.animation + pad4(ix);
      animationOut[rec.animationIndex].indices.push(i);
      xml.push('<SubTexture name="' + frameName + '" x="' + dx + '" y="' + dy + '" width="' + frameW + '" height="' + frameH + '" frameWidth="' + frameW + '" frameHeight="' + frameH + '" frameX="0" frameY="0"/>');
    }
    xml.push('</TextureAtlas>');
    callback(null, { pngDataUrl: canvas.toDataURL('image/png'), xml: xml.join('\n'), animations: animationOut,
      frameCount: frameRecords.length, width: canvas.width, height: canvas.height, framesPerAnimation: animations.map(function(a){return {name:a.name, frames:a.duration};}), source: 'Adobe Animate BTA/Spritemap' });
  }

  function buildCharacterJson(meta) {
    meta = obj(meta); var animations = arr(meta.animations), outAnimations = [], i, a;
    for (i = 0; i < animations.length; i++) {
      a = obj(animations[i]);
      outAnimations.push({ anim: String(a.name || 'idle'), name: String(a.prefix || a.name || 'idle'), fps: num(a.fps, 24),
        loop: !!a.loop, indices: arr(a.indices).length ? arr(a.indices) : [], offsets: arr(a.offsets).length ? arr(a.offsets) : [num(a.x, 0), num(a.y, 0)] });
    }
    return { animations: outAnimations, image: String(meta.image || 'characters/character'), scale: num(meta.scale, 1),
      sing_duration: num(meta.singDuration, 4), healthicon: String(meta.healthIcon || 'face'), position: arr(meta.position).length ? meta.position : [0, 0],
      camera_position: arr(meta.cameraPosition).length ? meta.cameraPosition : [0, 0], flip_x: !!meta.flipX, no_antialiasing: !!meta.pixelStage,
      healthbar_colors: arr(meta.healthbarColors).length === 3 ? meta.healthbarColors : [255, 0, 0],
      _portyou: { alpha: num(meta.alpha, 1), note: 'Review guessed animation names and offsets in Psych Engine Character Editor before release.' } };
  }

  root.PortYouSprites = { readAstcHeader: readAstcHeader, parseSparrowXml: parseSparrowXml,
    parseSpritemapJson: parseSpritemapJson, imageFromFile: imageFromFile, cutFrames: cutFrames,
    buildFnmmAtlas: buildFnmmAtlas, renderBtaToSparrow: renderBtaToSparrow, buildCharacterJson: buildCharacterJson };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PortYouSprites;
}(this));
