# ASTC-to-PNG upload audit

The user-provided `astc to png.zip` is a saved snapshot of the TextureCompression ASTC-to-PNG landing page, not a project source archive. The file named `astc-to-png.bin` inside that capture begins with an HTML document (`<!DOCTYPE html>`); the archive contains no `.wasm` ASTC decoder and no native decoder source module. The page links onward to the actual decoder page but the decoder implementation was not part of this upload.

To make the requested capability real and offline after installation, this project instead fetches the separately licensed `google/astc-codec` source at a pinned commit and compiles it into `libportyou_astc.so` through JNI. This decoder supports the ASTC LDR profile, not HDR. The Java bridge accepts standard 2D ASTC files, caps the compressed input at 64 MiB and output at a 2-megapixel defensive pixel cap, and saves PNG under the app's output directory.

The exact input bytes are kept under `references/astc-note-skin/` for format examples. Do not overwrite or reinterpret those source files when decoding. The native APK build and decoding on a physical Android 5+ phone have not yet been verified in this environment.
