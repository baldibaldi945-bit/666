# Android build notes

## Project configuration

- Application ID: `com.axelzerox23.portyou`
- Minimum Android API: 21 (Android 5.0)
- Target SDK: 28
- Compile SDK: 28
- Android Gradle Plugin: 3.2.1
- Expected Gradle version: 4.6
- Java toolchain: JDK 8
- No network permission is declared; conversion logic and UI assets are local.

## Build with Android Studio

1. Install a JDK 8 distribution and Android Studio that can load Android Gradle Plugin 3.2.1.
2. Install Android SDK Platform 28, Build Tools 28.0.3, CMake 3.10.2 and Android NDK 20.0.5594570.
3. From the repository root, fetch the local codec sources/assets:

   ```bash
   sh scripts/fetch-native-deps.sh
   sh scripts/fetch-codecs.sh
   ```

4. Open the `android/` directory as the Gradle project.
5. Use Gradle 4.6 and JDK 8 for this legacy Android plugin.
6. Run the `assembleDebug` task.
7. Install `android/app/build/outputs/apk/debug/app-debug.apk` on a test device.

The canonical WebView page and Psych template live in `app/` and `templates/PsychEngine-Mod-Template/`. The Gradle task `syncPortYouAssets` automatically recreates `android/app/src/main/assets/www/` and `android/app/src/main/assets/psych-template/` as part of `preBuild`, before Android merges assets. These generated mirrors are intentionally excluded from Git to avoid storing the same images and audio twice. The helper `sh scripts/sync-android-assets.sh` remains available for manually previewing/regenerating the mirrors, but it is not required before a Gradle build.

## GitHub Actions

The workflow fetches the pinned ASTC decoder source and local OGG encoder, installs JDK 8, Gradle 4.6, Android SDK 28, CMake and NDK 20, then builds and uploads the debug APK as an Actions artifact. The first run must be checked to confirm JitPack/JNI builds successfully.

## Android 5+ compatibility notes

`minSdkVersion 21` sets the install floor to Android 5.0. This is intentional because HTML file inputs inside WebView require the API 21 `WebChromeClient.onShowFileChooser` callback; the host now handles single/multiple selection and cancellation. This API-level setting does not certify every Android 5 handset: verify the system WebView provider, file picker, canvas memory, audio decoders, native ABIs and available storage on a real device. The audio mixer uses Web Audio (`AudioContext`) and a bundled OGG Vorbis encoder. The ASTC LDR module is native C++ and requires NDK/CMake; the archive reader includes 7-Zip native binaries.

The Java host imports ZIP/FNMM via streaming ZIP I/O and routes other supported formats through 7-Zip-JBinding auto-detection. Nevertheless, a 2GB archive can exceed available internal storage or heap indirectly when the JavaScript layer enumerates many files or builds image canvases. Use much smaller mods during initial testing.

## Build status

No APK is included because the current build environment did not have Gradle or Android SDK installed. The source configuration and CI workflow are included; this execution environment cannot run Gradle/Android SDK, so the native APK build and CI result remain unverified.
