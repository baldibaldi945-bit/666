# Audit of user-provided source archives

This note records the structural facts used to build the converters. It is not a claim that every possible mod using these engines follows the exact same layout.

## V-Slice sample: `(TSE)Enterprise V-SLICE PORT BY DANYPR008 no shader Opt.zip`

Observed structure and contents:

- 1,425 chart notes in the supplied `enterprise-chart.json` under the `normal` difficulty.
- Chart metadata uses millisecond time format and a base tempo of 145 BPM.
- The sample references three character IDs (`bf-gf`, `nogf`, `majin-p3`) and stage `rerun`.
- It contains 39 event entries, including `FocusCamera`, `ChangeCharacter`, and `PlayVideo`.
- Ten character JSON definitions, one stage, one level, ASTC image assets, Sparrow XML, HXC/Haxe scripts, OGG audio, and an MP4 video were found.

Conversion policy:

- Convert notes and tempo/focus information into Psych chart structure.
- Preserve unknown event payloads in a custom-event row and report that the runtime implementation is missing.
- Preserve original ASTC files byte-for-byte. The separate native ASTC LDR tool may export a PNG copy without overwriting the original; HDR/3D formats remain unsupported.
- Convert available character/stage/level JSON fields where the structures are understood.
- Retain original Haxe/HXC source as reference rather than pretending it was fully translated.

## Funkin' Maker sample: `مود فونكي ميكر عشان تتفحص بنيته بعناية.FNMM`

The uploaded `.FNMM` was a ZIP archive containing:

- `data.json`, `events.json`, `scene.json`, and `music.ogg`.
- `sprites/<folder>/sprite.json` and PNG sprite strips.
- `data.json` uses BPM 102 and two strum lines with four direction collections per line.
- Note timestamps and durations are stored in seconds in the supplied sample.
- `events.json` contains `ObjectSpriteSet` and `ObjectChartChange` actions.
- `scene.json` includes background, girlfriend, and player objects; the player uses strum line 0.
- `sprite.json` stores frame numbers, speed and offsets but does not explicitly name animation groups in the supplied sample.

Conversion policy:

- Treat strum line 0 as player lanes 0–3 and line 1 as opponent lanes 4–7 for this sample.
- Convert note times and durations from seconds to milliseconds.
- Rebuild strip frames into Sparrow PNG/XML atlases.
- Keep provisional animation labels visible for review instead of inventing definitive original labels.
- Preserve event records and flag incomplete runtime mappings.

## BTA / Spritemap utility archive

The provided HTML/JS source exposed an Adobe Animate-style structure:

- `ATLAS.SPRITES` contains sprite rectangles and optional rotation.
- `AN.TL` describes timeline layers and frame blocks.
- `SD.S` stores symbol definitions used by nested timeline references.
- Elements can refer to atlas sprites or nested symbols and may carry matrices and alpha values.

PortYou implements a core parser/renderer for these structures. Advanced Animate features still need test fixtures and parity checks against the source viewer.

## Chart converter HTML

The original `convert_charts_to_psych.html` was copied into `references/convert_charts_to_psych_original.html` unchanged. It is kept as a reference; new production code lives in `app/js/converters.js`.
