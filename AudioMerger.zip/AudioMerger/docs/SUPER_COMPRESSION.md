# Super-compressed repository package

## Result

- Previous v4 ZIP: 43,962,602 bytes (41.93 MiB).
- Optimized v5 ZIP: 22,311,367 bytes (21.28 MiB).
- Saved: 21,651,235 bytes (20.65 MiB), approximately 49.2%.

## Why this is safe

The old repository stored a complete duplicate of the app UI/media tree in both `app/` and `android/app/src/main/assets/www/`, plus a duplicate Psych template in `templates/` and `android/app/src/main/assets/psych-template/`.

All 68 mirrored UI/media files and all 57 mirrored template files were byte-identical to their canonical source files. Only these generated copies were removed from the GitHub ZIP. No original UI artwork, audio, source code, template file, converter, test, or reference file was deleted.

The Android Gradle project now runs `syncPortYouAssets` as a dependency of `preBuild`. It regenerates:

- `android/app/src/main/assets/www/` from `app/`
- `android/app/src/main/assets/psych-template/` from `templates/PsychEngine-Mod-Template/`

The generated folders are listed in `.gitignore`, preventing them from being committed as duplicate data again. The manual `scripts/sync-android-assets.sh` helper is retained.

## Verification

- Ran all four Node test suites successfully.
- Ran `node --check` on all JavaScript source files successfully.
- Ran shell syntax checks on the asset/dependency helper scripts.
- Ran the manual asset sync helper and compared SHA-256 hashes for all 87 generated files; every generated file matched its canonical source.
- Verified the final ZIP archive with `unzip -t`.

A Gradle/APK build was not run in this environment, so the Android build task still requires confirmation in Android Studio or GitHub Actions.
