# User-provided TXT instructions — audit and implementation map

The application ZIP contains nested UI archives; their instruction files were extracted and read. The items below record what those TXT files requested and how this source snapshot handles each part. Screenshots/artwork remain in `app/assets/ui/` unchanged.

## 1. Main application interface

**TXT request:** Keep the supplied full-screen artwork as the UI, play loop music while the app is open, pause it when the app leaves the foreground, play touch sounds, and quickly change the artwork when the user selects Stage, V-Slice, Funkin' Maker, or Settings.

**In this project:** The five home artwork states are preserved. Hotspots and quick-action buttons open the corresponding screens; selecting a quick action previews its supplied artwork. The local loop track pauses on activity/visibility pause and resumes when the app returns. A separate touch-sound and music toggle is present. The transition is a fast image swap rather than a frame-by-frame animation.

## 2. Stage editor interface

**TXT request:** Import a compressed mod, discover its stages/charts/characters and assets, allow stage and character selection, inspect JSON and Lua shader references, and show a live stage/camera preview. The original rectangle in the drawing was a camera viewport, not decoration.

**In this project:** The Android host imports ZIP/FNMM by ZIP signature and uses 7-Zip-JBinding auto-detection for 7z, RAR, TAR, GZip, BZip2 and the additional formats listed by the library, scans stage/character JSON and image candidates, lets the user select files, reads their key fields, and can load a chosen PNG/JPG into the preview canvas. Position and scale controls adjust that preview. The native bridge caps a single image read at 15MB and a generated base64 image write at 64MB. This is an inspection and single-image stage preview, not yet a full runtime recreation of every stage, character, camera, shader and layer. It can still produce a conversion report when some assets are absent.

## 3. Character replacement and sprite editor

**TXT request:** Identify classic Sprite Sheet (JSON/PNG/XML) versus Animate-style Sprite Map (animation JSON + one or more Spritemap JSON/PNG pairs); permit multiple maps; build a character JSON when missing; expose scale, alpha, flip, per-animation offsets, healthbar colour, and icon replacement; merge up to three icon frames while preserving dimensions; accept ASTC and decode it.

**In this project:**

- Classic Sparrow XML and common JSON frame metadata can be read and repacked into PNG/XML.
- A core BTA/Adobe Animate path can composite timeline/symbol frames from one Spritemap PNG + Spritemap JSON + Animation JSON.
- Funkin' Maker sprite strips can be rebuilt from `sprite.json` and PNG strips.
- A Character JSON editor exposes scale, alpha helper, position, camera offset, flip-X, sing duration, per-animation `offsets`, and healthbar RGB.
- An icon strip builder merges one to three images horizontally without scaling them.
- ASTC files remain preserved byte-for-byte in converted archives. A separate native ASTC LDR tool can decode standard 2D ASTC to PNG; it is capped at 2 megapixels, does not support HDR, and requires the native dependency fetch/build step.
- Multiple Spritemap pages, all Animate feature variants, per-animation visual flip, a full animated character preview, and automatic asset-role inference still need further work.

## 4. Note/hold editor

**TXT request:** Accept PNG/XML notes atlas plus a detached hold PNG (and merge where required), preserve an already-combined atlas, adjust note opacity, set hold above/below the notes, and generate a local script/settings file for the selected mod.

**In this project:** The notes tool accepts Notes PNG/XML and optional Hold PNG/XML, combines the pixel sheets side-by-side, shifts the hold XML x-coordinates, prefixes hold frame names, and exports PNG/XML/config JSON. It does not rewrite Psych Engine's internal sustain-note draw ordering by itself: the selected above/below setting is recorded in the config, but needs a tested engine-side runtime implementation before it changes draw order in-game.

## 5. Shader editor

**TXT request:** Add multiple shaders, allow character selection, opacity/strength/noise controls, and a drawing screen with brush, eraser, undo/redo, brush size/opacity and colour wheel. The drawn effect should follow the character's position.

**In this project:** Multiple shader source files are read into one editor view; target character and opacity/strength/noise values are recorded. A lightweight transparent canvas supports brush colour, brush size, opacity, eraser, undo, redo and clear. It exports a mask PNG plus JSON settings. This mask is not automatically attached to a moving character: the selected shader must implement sampling of that mask and a Psych Lua loader/attachment must be validated for the selected mobile engine.

## 6. Settings, descriptions and links

**TXT request:** Image 1 is the first settings artwork; images 2–5 rotate randomly on later visits only. The globe opens the language design (image 6), info opens the app description (image 9), friends opens image 8, sound opens image 10, YouTube opens image 11 and Instagram opens image 12. The red-haired character links to Akram's channel. Language choices include Arabic, Syrian Arabic, French, Thai and Japanese.

**In this project:** The first visit uses image 1, later visits randomize only images 2–5. Invisible hit-zones are placed over the hand-drawn symbols. The language/about/sound/social views use the supplied image assets 6, 9, 10, 11 and 12; the friends page uses image 8. The app description is translated into the five requested choices. Tool screens are still primarily Arabic, so full-app localization is incomplete. The red-haired character links to the Akram URL supplied by the user. The personal YouTube URL for AxelzeroX23 was not present in the message, so no guessed URL was added.

## 7. Template TXT files

All non-empty `readme.txt` files in `modTemplate.zip` are retained inside `templates/PsychEngine-Mod-Template/`. Their guidance describes the intended Psych folders for characters, custom events, custom note types, song charts, credits, intro text, achievements, settings, translated assets, achievement icons, character images, credit icons, dialogue images, character icons (`icon-` prefix and minimum 300×150), story menu backgrounds, menu characters, difficulty images, note skins (PNG/XML plus `list.txt`), note splashes (TXT/PNG/XML plus `list.txt`), music, global/song scripts, shaders (.frag/.vert), songs (`Inst.ogg`/`Voices.ogg`), stages, MP4 videos at 1280×720, and week JSON.

The source template remains a reference starting point; the converter does not yet generate every optional feature described in those template readmes.
