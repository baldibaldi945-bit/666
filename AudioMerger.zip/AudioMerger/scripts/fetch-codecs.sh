#!/bin/sh
# Downloads the offline Ogg Vorbis encoder used by the local WebView.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
OUT="$ROOT/app/js/vendor"
BASE="https://raw.githubusercontent.com/higuma/ogg-vorbis-encoder-js/master/lib"
mkdir -p "$OUT"
curl --fail --location --retry 3 "$BASE/OggVorbisEncoder.min.js" -o "$OUT/OggVorbisEncoder.min.js"
curl --fail --location --retry 3 "$BASE/OggVorbisEncoder.min.js.mem" -o "$OUT/OggVorbisEncoder.min.js.mem"
curl --fail --location --retry 3 "https://raw.githubusercontent.com/higuma/ogg-vorbis-encoder-js/master/LICENSE.txt" -o "$OUT/OGG-ENCODER-LICENSE.txt"
printf '%s\n' 'Offline Ogg Vorbis encoder assets downloaded.'
