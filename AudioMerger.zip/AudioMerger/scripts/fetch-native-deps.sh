#!/bin/sh
# Fetch the pinned Google ASTC LDR decoder source. The APK runs fully offline afterwards.
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
DEST="$ROOT/android/app/src/main/cpp/third_party/astc-codec"
COMMIT="b56a50064caf2a590ba43699e0074690fcd431bf"
mkdir -p "$(dirname "$DEST")"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
curl --fail --location --retry 3 "https://android.googlesource.com/platform/external/astc-codec/+archive/$COMMIT.tar.gz" -o "$TMP/astc-codec.tar.gz"
mkdir -p "$DEST"
tar -xzf "$TMP/astc-codec.tar.gz" -C "$DEST"
test -f "$DEST/include/astc-codec/astc-codec.h"
test -f "$DEST/LICENSE"
test -f "$DEST/src/decoder/astc_file.cc"
printf '%s\n' "ASTC LDR source checked out at $COMMIT."
