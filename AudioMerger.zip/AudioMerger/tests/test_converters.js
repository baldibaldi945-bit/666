'use strict';
var assert = require('assert');
var fs = require('fs');
var path = require('path');
var C = require('../app/js/converters.js');
var S = require('../app/js/sprite-tools.js');

assert.strictEqual(C.flipLane(0), 4, 'player left lane flips to opponent left');
assert.strictEqual(C.flipLane(7), 3, 'opponent right lane flips to player right');
assert.strictEqual(C.flipLane(9), 9, 'non-standard lanes are unchanged');

var vChart = {
  scrollSpeed: { normal: 1 },
  notes: { normal: [{ t: 0, d: 0, l: 500 }, { t: 3000, d: 4, l: 250 }] },
  events: [
    { t: 0, e: 'FocusCamera', v: { char: 1 } },
    { t: 600, e: 'ChangeCharacter', v: { character: 'dad', newchar: 'majin' } },
    { t: 800, e: 'NovelEvent', v: { sample: true } }
  ]
};
var vMeta = {
  songName: 'Test', timeFormat: 'ms', timeChanges: [{ t: 0, bpm: 120 }, { t: 1000, bpm: 150 }],
  playData: { difficulties: ['normal'], characters: { player: 'bf', opponent: 'dad', girlfriend: 'gf' }, stage: 'stage' }
};
var v = C.convertVSlice(vChart, vMeta, { difficulty: 'normal' });
var vNotes = [].concat.apply([], v.chart.song.notes.map(function (s) { return s.sectionNotes; }));
assert.strictEqual(vNotes[0][1], 4, 'opponent-focused V-Slice event switches 0..3 to opponent lanes');
assert.strictEqual(vNotes[1][1], 0, 'opponent-focus conversion swaps an existing opponent lane exactly once');
assert(v.chart.song.events.some(function (g) { return g[1].some(function (e) { return e[0] === 'PortYou Unmapped Event'; }); }), 'unknown V-Slice event payload is retained');
assert(v.chart.song.notes.some(function (s) { return s.changeBPM && s.bpm === 150; }), 'metadata timeChanges create a BPM section change');
var flipped = C.convertVSlice(vChart, vMeta, { difficulty: 'normal', flipSides: true });
var fNotes = [].concat.apply([], flipped.chart.song.notes.map(function (s) { return s.sectionNotes; }));
assert.strictEqual(fNotes[0][1], 0, 'explicit side flip reverses lane ownership');

var fmData = { bpm: 100, strumLines: [
  [[{ start: 1, duration: 0.5 }], [], [], []],
  [[], [{ start: 2, duration: 0.25 }], [], []]
] };
var fmEvents = { events: [{ time: 3, actions: [{ type: 'ObjectSpriteSet', props: { object: 2, sprite: 'new' } }] }] };
var fmScene = { objects: [
  { spr: 'background', x: 10, y: 20, strumLine: -1, visible: true, scale: { x: 1, y: 1 } },
  { spr: 'player', x: 300, y: 400, strumLine: 0, scale: { x: 1, y: 1 } },
  { spr: 'gf', x: 200, y: 350, strumLine: -1, scale: { x: 1, y: 1 } }
], cameras: [{ x: 100, y: 200, scale: 0.8 }], icons: ['icon1'] };
var fm = C.convertFunkinMaker(fmData, fmEvents, fmScene, { song: 'fnmm-test' });
var fmNotes = [].concat.apply([], fm.chart.song.notes.map(function (s) { return s.sectionNotes; }));
assert(fmNotes.some(function (n) { return n[0] === 1000 && n[1] === 0 && n[2] === 500; }), 'FNMM player notes become milliseconds and player lanes');
assert(fmNotes.some(function (n) { return n[0] === 2000 && n[1] === 5 && n[2] === 250; }), 'FNMM second line maps to opponent lanes');
assert.strictEqual(fm.stage.boyfriend[0], 300, 'scene player sprite maps to boyfriend position');
assert.strictEqual(fm.stage.girlfriend[0], 200, 'scene GF sprite maps to girlfriend position');
assert(fm.chart.song.events.length, 'FNMM events are retained');

var xml = '<TextureAtlas><SubTexture name="idle0000" x="0" y="0" width="32" height="40"/></TextureAtlas>';
assert.strictEqual(S.parseSparrowXml(xml).length, 1, 'Sparrow XML frame parser finds subtextures');
var btaMap = S.parseSpritemapJson({ ATLAS: { SPRITES: [{ SPRITE: { name: 'frameA', x: 2, y: 3, w: 24, h: 32, rotated: false } }] } });
assert.strictEqual(btaMap.length, 1, 'BTA Spritemap parser recognises ATLAS.SPRITES');
assert.strictEqual(btaMap[0].name, 'frameA', 'BTA sprite names are retained');
var char = S.buildCharacterJson({ animations: [{ name: 'idle', prefix: 'BF idle dance', x: 3, y: -2 }], healthbarColors: [23, 45, 67], alpha: 0.6 });
assert.deepStrictEqual(char.animations[0].offsets, [3, -2], 'Psych animation offsets are emitted as offsets array');
assert.deepStrictEqual(char.healthbar_colors, [23, 45, 67], 'healthbar RGB is saved in character JSON');
var astc = new Uint8Array(16); astc.set([0x13, 0xAB, 0xA1, 0x5C, 4, 4, 1, 64, 0, 0, 64, 0, 0, 1, 0, 0]);
assert.strictEqual(S.readAstcHeader(astc.buffer).valid, true, 'ASTC reader validates the file header');
var sampleAstcPath = path.join(__dirname, '..', 'references', 'astc-note-skin', 'ReRun_NOTE_assets.astc');
if (fs.existsSync(sampleAstcPath)) {
  var sampleAstc = fs.readFileSync(sampleAstcPath);
  var sampleBuffer = sampleAstc.buffer.slice(sampleAstc.byteOffset, sampleAstc.byteOffset + sampleAstc.byteLength);
  var sampleHeader = S.readAstcHeader(sampleBuffer);
  assert.strictEqual(sampleHeader.valid, true, 'real user-provided ASTC sprite skin header is recognised');
  assert(sampleHeader.width > 0 && sampleHeader.height > 0, 'real ASTC sample dimensions are read');
}
console.log('PortYou converter tests passed.');
