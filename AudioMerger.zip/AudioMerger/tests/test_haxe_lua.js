'use strict';
var assert = require('assert');
var HaxeLua = require('../app/js/haxe-lua.js');

var source = [
  'class Demo {',
  '  override function onUpdate(elapsed:Float):Void {',
  '    FlxG.camera.zoom += elapsed;',
  "    boyfriend.playAnim('hey', true);",
  '    if (FlxG.keys.justPressed.SPACE) {',
  "      FlxG.sound.play(Paths.sound('hit'), 1);",
  '    }',
  '    else if (health < 0.5) {',
  '      game.health += 0.1;',
  '    }',
  '    else {',
  "      trace('ok');",
  '    }',
  "    FlxTween.tween(game.boyfriend, {x: 100, alpha: 0.5}, 1, {ease: FlxEase.quadOut});",
  '    switch (state) {',
  "      case 1: trace('one');",
  "      default: trace('other');",
  '    }',
  "    trace('after');",
  '  }',
  '}'
].join('\n');

var result = HaxeLua.translate(source);
assert(result.lua.indexOf('function onUpdate(elapsed)') >= 0, 'callback elapsed parameter must be retained');
assert(result.lua.indexOf("characterPlayAnim('boyfriend', 'hey', true)") >= 0, 'character animation should map to Psych Lua');
assert(result.lua.indexOf("keyboardJustPressed('space')") >= 0, 'keyboard names should be normalized');
assert(result.lua.indexOf("cameraShake('game'") === -1, 'unrelated camera shake should not be fabricated');
assert(result.lua.indexOf("setProperty('camGame.zoom', getProperty('camGame.zoom') + elapsed)") >= 0, 'camera compound assignment should map');
assert(result.lua.indexOf("doTweenX('portyou_boyfriend_x'") >= 0, 'simple X tween should map');
assert(result.lua.indexOf("doTweenAlpha('portyou_boyfriend_alpha'") >= 0, 'simple alpha tween should map');
assert(result.lua.indexOf('-- TODO_PORTYOU [opaque Haxe block]') >= 0, 'unsupported switch body should be preserved as TODO comments');
assert(result.lua.indexOf("debugPrint('after')") >= 0, 'code after unsupported switch must not be swallowed');
assert(!result.lua.match(/unmatched Haxe block/), 'recognized control blocks should close cleanly');
assert(result.warnings.length === 1, 'only the unsupported switch should be flagged in this sample');

var noteCallbacks = HaxeLua.translate([
  'class Notes {',
  '  function goodNoteHit(id:Int, noteData:Int, noteType:String, isSustainNote:Bool):Void {',
  '    trace(noteData);',
  '  }',
  '}'
].join('\n'));
assert(noteCallbacks.lua.indexOf('function goodNoteHit(id, noteData, noteType, isSustainNote)') >= 0, 'note callback parameters must all be kept');
assert(noteCallbacks.lua.indexOf('debugPrint(noteData)') >= 0, 'note callback body should be converted');

var sizeMapping = HaxeLua.translate([
  'function onCreate():Void {',
  '  boyfriend.setGraphicSize(320, 0);',
  '  gf.setGraphicSize(180, 240);',
  '}'
].join('\n'));
assert(sizeMapping.lua.indexOf("setGraphicSize('boyfriend', 320, 0)") >= 0, 'setGraphicSize must keep pixel-size semantics');
assert(sizeMapping.lua.indexOf("setGraphicSize('gf', 180, 240)") >= 0, 'girlfriend should map to Psych gf with explicit dimensions');
assert(sizeMapping.lua.indexOf('scaleObject(') === -1, 'pixel dimensions must not be passed to the ratio-based scaleObject helper');

var simpleIf = HaxeLua.translate([
  'function onCreate():Void {',
  '  if (true) {',
  "    trace('a');",
  '  }',
  '  else {',
  "    trace('b');",
  '  }',
  '}'
].join('\n'));
assert(simpleIf.lua.indexOf('elseif') === -1, 'plain else must not be emitted as elseif');
assert(simpleIf.lua.indexOf('else\n') >= 0, 'standalone else should remain paired with its if');

console.log('Haxe-to-Psych-Lua translator tests passed.');
