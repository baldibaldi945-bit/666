'use strict';
var assert = require('assert');
var fs = require('fs');
var path = require('path');
var html = fs.readFileSync(path.join(__dirname, '../app/index.html'), 'utf8');
var scripts = fs.readdirSync(path.join(__dirname, '../app/js')).filter(function (f) { return f.endsWith('.js'); })
  .map(function (f) { return fs.readFileSync(path.join(__dirname, '../app/js', f), 'utf8'); }).join('\n');
var buttonPattern = /<button\b([^>]*)>/gi, match, count = 0, unwired = [];
while ((match = buttonPattern.exec(html))) {
  count++;
  var attrs = match[1];
  var id = (attrs.match(/\bid=["']([^"']+)["']/i) || [])[1];
  if (/\bdata-screen\s*=|\bdata-art(?:-src|-target)?\s*=/.test(attrs)) continue;
  if (!id) { unwired.push('button without id or data action: ' + attrs.slice(0, 100)); continue; }
  var qId = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var direct = new RegExp("q\\(['\\\"]" + qId + "['\\\"]\\)\\.(?:onclick|onchange|oninput|onmousedown|onmouseup)").test(scripts);
  var queried = new RegExp("q\\(['\\\"]" + qId + "['\\\"]\\)").test(scripts);
  if (!direct && !queried) unwired.push(id);
}
assert(count > 40, 'the full original tool UI should still be present');
assert.deepStrictEqual(unwired, [], 'every button should have a direct handler or a delegated action');
assert(html.indexOf('https://youtube.com/@axelzerox023?si=bMgXdEsqem0vC_Yf') >= 0, 'developer YouTube URL should be present');
assert(!/target=[\"']_blank[\"']/.test(html), 'external links should use the Android host URL handler in the same WebView');
assert((html.match(/id="settingsArtwork"/g) || []).length === 1, 'settings subpages must reuse one artwork node');
assert(html.indexOf('<option value="ar-SA">') >= 0 && html.indexOf('<option value="pt-BR">') >= 0, 'Saudi Arabic and Brazilian Portuguese are in the selector');
assert(scripts.indexOf('onShowFileChooser') === -1, 'native file chooser belongs to the Android host, not the web scripts');
console.log('UI wiring audit passed for ' + count + ' buttons.');
